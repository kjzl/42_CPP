Research 11: Machine Learning for Databases II

SIGMOD '20, June 14-19, 2020, Portland, OR, USA

when the spill bucket contains less than  $5\%$  of the elements, therefore, we set the minimum bucket capacity to be  $t = 100$ .

3.1.3 The effect of model quality on the spill bucket size. The formula that we presented in the section above shows the expected size of the spill bucket when the model perfectly learns the underlying distribution. However, in this section, we analyze the expected size of the spill bucket for an approximation model that is trained on a small sample of the input.

For this analysis, we again assume that we can treat the sample as independently generated from the underlying distribution, and that we use unit-capacity buckets. For simplicity, we also linearly transform the input space into the range [0, 1]. Let  $f(x)$  be the CDF of the underlying distribution and  $g(x)$  be our approximation that is learned from the sample.

In the mapping phase, the keys in the range  $[a,b]$  will be mapped to  $N\cdot (g(b) - g(a))$  buckets. Whereas, in expectation, there will be  $N\cdot (f(b) - f(a))$  keys present in the range  $[a,b]$ . The difference between the number of elements that are actually present in that range and the number of buckets that they are mapped to, leads to bucket overflows.

For a small range of input keys  $dx$ , the number of elements in the array within this input range  $[x, x + dx)$  will be proportional to  $f'(x)dx$  but our approximation will map them to  $g'(x)dx$  buckets. So the problem turns into hashing  $f'(x)dx$  elements into  $g'(x)dx$  buckets of unit capacity. The number of empty buckets, which is same as number of overflowing elements, in this input range will be  $g'(x)e^{-f'(x) / g'(x)}dx$ , which will be integrated over the input range [0,1]. This gives us the following equation for measuring the number of overflowing elements w.r.t. the model's quality of approximation:

$$
\mathbf {E} [ s ] = N \cdot \int_ {0} ^ {1} g ^ {\prime} (x) e ^ {\frac {- f ^ {\prime} (x)}{g ^ {\prime} (x)}} d x
$$

Using Jensen's inequality[25], it can be shown that this number is always greater than  $N / e$  with equality occurring when  $f'(x) = g'(x)$ . This shows that, for small samples, learning the underlying distribution leads to lesser elements in the spill bucket. A qualitative aspect of the formula above is that one needs to approximate the derivative of the CDF function (the PDF function) in order to minimize the expected size of spill bucket, and therefore maximize performance.

3.1.4 Choosing the sample size. We now discuss how the model quality changes w.r.t increasing sample size. We approximate the CDF of an element in a sample by looking at its position in the sorted sample. This empirical CDF of the sample is different from its CDF in the distribution that generated the sample. The Dvoretzky-Kiefer-Wolfowitz inequality[12] is one method for generating CDF-based confidence bounds and it states that for a given sample size  $n$  the difference between empirical CDF and real CDF is proportional to

![img-6.jpeg](img-6.jpeg)
Figure 7: Sorting time for various sampling rates of 100M normally-distributed keys (log-log scale).

$O(1 / \sqrt{n})$ . So, as the sample size increases the accuracy of its empirical CDF improves making the model better.

On other hand, a large sample increases the training time creating a trade-off between model quality and runtime performance. Figure 7 shows the trend of the time to sort the array (Sorting Time) and total time (Training and Sorting) w.r.t the sample size, while keeping the other parameters constant. In the figure, as sample size increases we can see the sorting time decreases because a larger sample leads to a better model quality. However, the training time keeps on increasing with the sample size. We empirically found that a sampling rate of  $1\%$  provides a good balance in this trade-off as is evident from the graph.

# 3.2 Complexity

Stage 1 of the sorting algorithm scans the input keys sequentially and for each key it uses the trained CDF model to predict which bucket to go to. This process takes  $O(N \cdot L)$  time, where  $L$  is the number of layers in the model. Since we split the buckets progressively using a fan-out factor  $f$  until a threshold size  $t$ , the number of iterations and the actual complexity depend on the choice of  $f$  and  $t$ . However, in practice we use a large fan-out factor, therefore the number of iterations can be considered constant.

On the other hand, Stage 2 of the algorithm uses a routine similar to Counting Sort, which is a linear-time sorting procedure with respect to the bucket capacity  $(t)$ , hence accounting for an  $O(N)$  term. Assuming that the CDF model is monotonic, the worst case complexity of Stage 3 is  $O(Nt)$  due to the fact that we use Insertion Sort and we have a threshold on the buckets. Otherwise, the worst case for a non-monotonic model would be  $O(N^2)$ . However, the constant term of this stage depends on the model quality: A good model, as the one described above, will provide a nearly-sorted array before the Insertion Sort subroutine is called, hence making this step non-dominant (refer to Figure 13).

Finally, as in the touch-up stage, the performance of Stage 4 also depends on the model quality. Assuming we employ a traditional, asymptotically optimal, comparison-based sorting routine for the spill bucket  $S$ , this stage's worst-case