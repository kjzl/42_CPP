Research 11: Machine Learning for Databases II

SIGMOD '20, June 14-19, 2020, Portland, OR, USA

logically split further into  $f$  smaller buckets (Lines 20-21) until the buckets are smaller than threshold  $t$  (Line 11). Note that, in order to preserve memory, we reuse the arrays  $A$  and  $B$  by simply swapping the read and write pointers (Line 22) and updating the bucket splitting parameters (Lines 20-21).

Step 2: When the bucket capacity reaches  $t$ , we switch to a model-based Counting Sort-style routine (Lines 23-38) to map the items to their final positions. We again do that using the model, which now predicts the exact index position, not the bucket. That is, we first calculate the final position for every key (Line 28) and store in array  $K$  the count of keys that are mapped to each predicted index (Line 29). The array  $K$  is then transformed to a running total (Line 31). Finally, we place the items into their final position using the cumulative counts (Lines 32-38), which is similar to the Counting Sort routine[7, pp.168-170]. As we only sort one bucket at a time and want to keep the array size of  $K$  small, we use an offset to set the start index of the bucket in Lines 28-36.

We switch to the model-based Counting Sort for two reasons. First, and most importantly, it helps improve the overall sorting time as we are able to fully utilize our model's precision for fine-level predictions. Second, it helps reduce the number of overflows (see Section 3.1.2 for more details).

Step 3: After the last sorting stage we remove any empty space and, for non-monotonic models, correct any potential mistakes with Insertion Sort(Line 40).

Step 4: Finally, because we used a spill bucket  $(S)$  for the overflowing elements in Stage 1, we have to sort it and merge it with the sorted buckets before returning (Lines 42-43). Provided that the sorting algorithm for the spill bucket is stable, Learned Sort also maintains the stability property.

# 2.3 Implementation optimizations

The pseudocode in Algorithm 2 gives an abstract view of the procedure, however, we have used a number of optimizations at the implementation level. Below we describe the most important ones:

- We process elements in batches. First we use the model to get the predicted indices for all the elements in the batch, and then place them into the predicted buckets. This batch-oriented approach maintains cache locality.
- As in Algorithm 1, we can over-provision array  $B$  by a small factor (e.g.,  $1.1 \times$ ) in order to increase the bucket sizes and consequently reduce the number of overflowing elements in the spill bucket  $S$ . This in turn reduces the sorting time for  $S$ .
- Since the bucket sizes in Stage 2 are small (i.e.,  $b \leq t$ ), we can cache the predicted position for every element in the current bucket in Line 28 and reuse them in Line 34.
- In order to preserve the cache's and TLB's temporal locality, we use a bucket-at-a-time approach, where we

Algorithm 2 The Learned Sort algorithm
Input  $A$  - the array to be sorted
Input  $F_{A}$  - the CDF model for the distribution of  $A$
Input  $f$  - fan-out of the algorithm
Input  $t$  - threshold for bucket size
Output  $A^{\prime}$  - the sorted version of array  $A$
1: procedure LEARNED-SORT(A,  $F_{A},f,t$ )
2:  $N\gets |A|$  ▷ Size of the input array
3:  $n\gets f$  ▷  $n$  represents the number of buckets
4:  $b\gets [N / f]$  ▷  $b$  represents the bucket capacity
5:  $B\gets []\times N$  ▷ Empty array of size  $N$
6:  $I\gets [0]\times n$  ▷ Records bucket sizes
7:  $S\gets []$  ▷ Spill bucket
8: read_arr  $\leftarrow$  pointer to  $A$
9: write_arr  $\leftarrow$  pointer to  $B$
10: // Stage 1: Model-based bucketization
11: while  $b\geq t$  do ▷ Until bucket capacity reaches the threshold  $t$
12:  $I\gets [0]\times n$  ▷ Reset array I
13: for  $x\in$  read_arr do
14: pos  $\leftarrow$  [INFER(FA,x)·n]
15: if  $I[\mathrm{pos}]\geq b$  then ▷ Bucket is full
16: S.append(x) ▷ Add to spill bucket
17: else ▷ Write into the predicted bucket
18: write_arr[pos·b+I[pos]]  $\leftarrow x$
19: INIncrement I[pos]
20:  $b\gets [b / f]$  ▷ Update bucket capacity
21:  $n\gets [N / b]$  ▷ Update the number of buckets
22: PTRSWP(read_arr, write_arr) ▷ Pointer swap to reuse memory
23: // Stage 2: In-bucket reordering
24: offset  $\leftarrow 0$
25: for  $i\gets 0$  up to  $n$  do ▷ Process each bucket
26:  $K\gets [0]\times b$  ▷ Array of counts
27: for  $j\gets 0$  up to  $I[i]$  do ▷ Record the counts of the predicted positions
28: pos  $\leftarrow$  [INFER(FA, read_arr[offset+j])·N]
29: INIncrement K[pos - offset]
30: for  $j\gets 1$  up to  $|K|$  do ▷ Calculate the running total
31:  $K[j]\gets K[j] + K[j - 1]$
32:  $T\gets []$  ▷ Temporary auxiliary memory
33: for  $j\gets 0$  up to  $I[i]$  do ▷ Order keys w.r.t. the cumulative counts
34: pos  $\leftarrow$  [INFER(FA, read_arr[offset+j])·N]
35:  $T[j]\gets$  read_arr[offset+k[pos - offset]]
36: DECREMENT K[pos - offset]
37: Copy  $T$  back to read_arr[offset]
38: offset  $\leftarrow$  offset + b
39: // Stage 3: Touch-up
40: INSERTION-SORT-AND-COMPACT(read_arr)
41: // Stage 4: Sort &amp; Merge
42: SORT(S)
43:  $A^{\prime}\gets$  MERGE(read_arr,S)
44: return  $A^{\prime}$

perform all the operations in Lines 11-40 for all the keys in a single bucket before moving on to the next one.

The code for the algorithm can be found at http://dsg.csail.mit.edu/mlforsystems.

# 2.4 Choice of the CDF model

Our sorting algorithm does not depend on a specific model to approximate the CDF. However, it is paramount that the model is fast to train and has a very low inference time