Check for updates

ACM DIGITAL LIBRARY

Association for Computing Machinery

acm open

P

PDF Download
3318464.3389752.pdf
29 December 2023
Total Citations: 35
Total Downloads: 8282

Latest updates: https://dl.acm.org/doi/10.1145/3318464.3389752

RESEARCH-ARTICLE

Published: 11 June 2020

The Case for a Learned Sorting Algorithm

ANI KRISTO, Brown University, Providence, RI, United States

KAPIL EKNATH VAIDYA, Massachusetts Institute of Technology, Cambridge, MA, United States

UGUR CETINTEMEL, Brown University, Providence, RI, United States

SANCHIT MISRA, Intel Technology India Pvt Ltd., Bengaluru, KA, India

TIM KRASKA, Massachusetts Institute of Technology, Cambridge, MA, United States

Open Access Support provided by:
Brown University
Massachusetts Institute of Technology
Intel Technology India Pvt Ltd.

Citation in BibTeX format

SIGMOD/PODS '20: International Conference on Management of Data
June 14 - 19, 2020
OR, Portland, USA

Conference Sponsors:
SIGMOD

SIGMOD '20: Proceedings of the 2020 ACM SIGMOD International Conference on Management of Data (June 2020)
https://doi.org/10.1145/3318464.3389752
ISBN: 9781450367356