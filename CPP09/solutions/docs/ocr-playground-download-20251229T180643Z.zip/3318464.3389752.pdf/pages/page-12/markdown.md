Research 11: Machine Learning for Databases II

SIGMOD '20, June 14-19, 2020, Portland, OR, USA

![img-7.jpeg](img-7.jpeg)
Figure 8: The sorting throughput for normally distributed double-precision keys (higher is better).

$\mathrm{B + }$  tree indexes in database systems, a work that was followed up later on by [11]. In addition, other ML algorithms, as well as reinforcement learning, have been used to tune system parameters or optimize query execution plans in [27, 30, 34, 35, 58]. Finally, this new research trend has also reached other system applications outside databases, such as in scheduling [33], congestion control [24], and frequency estimation in data stream processing [20].

# 6 EVALUATION

The goal of this section is to:

- Evaluate the performance of Learned Sort compared to other highly-tuned sorting algorithms over real and synthetic datasets
- Explain the time-breakdown of the different stages of Learned Sort
- Evaluate the main weakness of Learned Sort: duplicates
- Show the relative performance of the in-place versus the out-of-place Learned Sort
- Evaluate the Learned Sort performance over strings.

# 6.1 Setup and datasets

As baselines, we compare against cache-optimized and highly tuned  $\mathrm{C + + }$  implementations of Radix Sort [51], Timsort [18], Introsort (std::sort), Histogram Sort[4], and  $\mathrm{IS^4o}$  [49] (one of the most optimized sorting algorithms we were able to find, which was also recently used in other studies [40] as a comparison point). Note that we use a recursive, equi-depth version of Histogram sort that adapts to the input's skew as to avoid severe performance penalties. While we are presenting only the most competitive baselines, we have, in

fact, conducted measurements against Mergesort, Heapsort, Insertion Sort, Shell Sort, Quicksort, and one of its improved variants - PDQS[44]. However, we did not consider them further as their performance was always worse than one of the other baselines. Note, that for all our experiments we include the model training time as part of the overall sorting time unless mentioned otherwise.

We evaluate the performance of our algorithm for numerical keys on both synthetic and real datasets of varying precision. For the synthetic datasets we generated the following distributions:

- Uniform distribution with min=0 and max=1
- Multimodal distribution that is a mixture of five normal distributions whose PDF is shown in the histogram below the performance charts in Figure 9
- Exponential distribution with  $\lambda = 2$  and scaled by a factor of  $10^{6}$  (80% of the keys are concentrated in 7% of the key domain)
- Lognormal distribution with  $\mu = 0$  and  $\sigma = 1$  that has an extreme skew (80% of the keys are concentrated in 1% of the key range)

We also use real-world data from OpenStreetMap[42] and sort on 100M longitude and latitude compound keys (osm/longlat) that are generated using the transformation  $\text{longlat} = 180 \cdot \text{lon} + \text{lat}$ , as in [11], as well as on their respective node IDs (osm/id). In addition, we use an IoT dataset [15] to sort on the iot/mem and iot/bytes columns (10M keys), which represent the amount of available memory and number of input bytes to a server machine at regular time intervals. Thirdly, we use the Facebook RW dataset (fb/rw) to sort on 1.1M collected user IDs from a random walk in the Facebook user graph[31]. Finally, we show results from TPC-H benchmark data on the customer account balances (tpch/bal - 3M keys), and order keys (tpch/o_key - 30M keys) for a scale factor of 20, which are of course not real but represents data which are often used to evaluate the performance of database systems. All datasets were randomly shuffled before sorting. We display the distribution of these datasets with histograms below each result in Figure 9.

All the experiments are measured on a server-grade Linux machine running on Intel® Xeon® Gold 6150 CPU @ 2.70GHz with 376GB of memory, and compiled with GCC 9.2 with the -03 flag for full optimizations³. The model we used for training was always 2-layers and contained 1000 leaf models, trained with a uniformly selected 1% sample of the array.