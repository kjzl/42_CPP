Research 11: Machine Learning for Databases II

SIGMOD '20, June 14-19, 2020, Portland, OR, USA

Algorithm 3 The inference procedure for the CDF model
Input  $F_{A}$  - the trained model  $(F_{A}[l][r]$  refers to the  $r^{th}$  model in the  $l^{th}$  layer) Input  $x$  - the key Output  $r$  - the predicted rank (between 0-1)
1: procedure INFER  $(F_{A},x)$
2:  $L\gets$  the number of layers of the CDF model  $F_{A}$
3:  $M^l\gets$  the number of models in the  $l^{th}$  layer of the RMI  $F_{A}$
4:  $r\gets 0$
5: for  $l\gets 0$  up to L do
6:  $r = x\cdot F_A[l][r].$  slope  $+F_{A}[l][r].$  intercept
7: return  $r$

to keep the overall sorting time low. Thus, models such as KDE[43, 47], neural networks or even perfect order-preserving hash functions are usually too expensive to train or execute for our purposes. One might think that histograms would be an interesting alternative, and indeed histogram-based sorting algorithms have been proposed in the past [7, pp.168-177]. Unfortunately, histograms have the problem that they are either too coarse-grained, making any prediction very inaccurate, or too fine-grained, which increase the time to navigate the histogram itself (see also Section 6.8).

Certainly many model architectures could be used, however, for this paper we use the recursive model index (RMI) architecture as proposed in [29] (shown in Figure 5). RMIs contain simple linear models which are organized into a layered structure, acting like a mixture of experts[29].

2.4.1 Inference. Algorithm 3 shows the inference procedure for an RMI architecture. During inference, each layer of the model takes the key as an input and linearly transforms it to obtain a value, which is used as an index to pick a model in the next layer (Line 6). The intermediate models' slope an intercept terms are already scaled out to the number of models in the next layer, hence avoiding additional multiplications at inference time, whereas the last layer will return a CDF value between 0 and 1. Note, that the inference can be extremely fast because the procedure uses simple data dependencies instead of control dependencies (i.e., if-statements), consequently making it easier for the optimizer to perform loop unrolling and even vectorization. Hence, for each layer, the inference requires only one addition, one multiplication, and one array look-up to read the model parameters[29].

2.4.2 Training Procedure. Algorithm 4 shows the training procedure, which can be on a small sample of the input array. The algorithm starts by selecting a sample and sorting it using an efficient deterministic sorting algorithm - e.g., std::sort - (Lines 2-3), creating a 3D array to represent a tree structure of training sets, and inserting all  $\langle \text{key}, \text{CDF} \rangle$  pairs into the top node  $T[0][0]$ . Here the empirical CDF for the training tuples is calculated as its index in the sorted sample over the sample size  $(i / |S|)$ . Starting at the root layer, the algorithm trains linear models working its way top-down.

![img-4.jpeg](img-4.jpeg)
Figure 5: A typical RMI architecture containing three layers

Algorithm 4 The training procedure for the CDF model
Input  $A$  - the input array
Input  $L$  - the number of layers of the CDF model
Input  $M^l$  - the number of linear models in the  $l^{th}$  layer of the CDF model
Output  $F_{A}$  - the trained CDF model with RMI architecture
1: procedure TRAIN(A, L, M)
2:  $S \gets \text{SAMPLE}(A)$
3: SORT(S)
4:  $T \gets [[|]]$  Training sets implemented as a 3D array
5: for  $i \gets 0$  up to  $|S|$  do
6:  $T[0][0].add((S[i], i/|S|))$
7: for  $l \gets 0$  up to  $L$  do
8: for  $m \gets 0$  up to  $M^l$  do
9:  $F_{A}[l][m] \gets$  linear model trained on the set  $\{t \mid t \in T[l][m]\}$
10: if  $l + 1 &lt; L$  then
11: for  $t \in T[l][m]$  do
12:  $F_{A}[l][m].\text{slope} \gets F_{A}[l][m].\text{slope} \cdot M^{l+1}$
13:  $F_{A}[l][m].\text{intercept} \gets F_{A}[l][m].\text{intercept} \cdot M^{l+1}$
14:  $i \gets F_{A}[l][m].\text{slope} \cdot t + F_{A}[l][m].\text{intercept}$
15:  $T[l + 1][i].add(t)$
16: return  $F_{A}$

The CDF model  $F_{A}$  can be implemented as a 2D array where  $F_{A}[l][r]$  refers to the  $r^{th}$  model in the  $l^{th}$  layer of the RMI. For the root model, the algorithm uses the entire sample as training set to calculate a slope and intercept term (Line 9). After it has been trained, for each of the training tuples, the root model predicts a CDF value and it scales it by  $M^{l + 1}$  (the number of models in the next layer) (Line 12-13). Then, it distributes these tuples into multiple training subsets that will be used to train each of the linear models in the subsequent layer. Each tuple goes to a training subset at index  $i$ , which is calculated in Line 14 by using the slope and intercept terms of the parent model. This partitioning process continues until the second-to-last layer of the RMI, and each of the newly created training subsets is used to train the corresponding linear models in a recursive fashion.

2.4.3 Training of the individual linear models. One way to train the linear models is using the closed-form of the univariate linear regression with an MSE loss function. However, when using linear regression training, it is possible that two neighboring linear models that are in the last layer of the CDF model predict values in overlapping ranges. Hence,