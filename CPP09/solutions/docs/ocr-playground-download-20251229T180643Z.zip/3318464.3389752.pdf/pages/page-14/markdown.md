Research 11: Machine Learning for Databases II

SIGMOD '20, June 14-19, 2020, Portland, OR, USA

![img-9.jpeg](img-9.jpeg)
Figure 10: The sorting rate for various strings datasets.

of  $27\%$ , and the other baselines by much larger margins. The same performance gain is also present for the high-precision real-world datasets (Figure 9B). Note, that we achieve a significant higher sorting rate for the tpch/bal data due to the fact that it is smaller, and incurs more cache benefits.

On the other hand, we observed that Radix Sort's performance improves when the input keys have less precision (Figure 9C). In this case, Learned Sort and all the other baselines algorithms remain unaffected, while Radix Sort gets a  $34\%$  performance boost. This improvement results from the fact that everything can be sorted on the most significant bits. However, it is necessary to note that Radix Sort's performance does not surpass that of Learned Sort.

Finally, in Figure 9A we show that for integers Learned Sort has an even higher throughput and, in some cases, even a bigger benefit. For example, on the synthetic integer dataset it is  $38\%$  better than  $\mathrm{IS}^4\mathrm{o}$  and twice as fast as Radix Sort. Whereas for the FB dataset and OSM IDs the performance difference compared to  $\mathrm{IS}^4\mathrm{o}$  is less because of the particular distribution of values and duplicates (see Section 4.3).

# 6.4 Sorting Strings

Figure 10 show the preliminary sorting rate for strings for our algorithm of Section 4.2 with respect to  $\mathrm{IS}^4\mathrm{o}$ , std::sort, and Timsort. In this experiment we excluded the training time for the model. However, it should be noted, that many real-world scenarios exist in which a dataset or a subset has to be sorted several times. For example, within a database recurring merge-joins operation or the sorting for the final result, would allow to pre-train models as similar (but not identical) subsets of the data might appear over and over again. Note, that we excluded Radix Sort from this comparison as it was significantly slower than any of the other baselines. For the data we used:

- addr: A set of 1M address strings from the OpenAddresses dataset (Northeast USA)[41].
- dict: A set of 479K words from an English dictionary[53].
- url: A list of 1.1M URLs from the Weblogs dataset[15] containing requests to a webserver for cs.brown.edu

![img-10.jpeg](img-10.jpeg)
Figure 11: The sorting rate of Learned Sort and the other baselines for varying degrees of duplicated keys and number of spikes, as well as on different Zipf distributions. The reference line represents the sorting rate of Learned Sort where there are no duplicates.

- bcmrk: 10M ASCII arrays generated using the code from the SortBenchmark dataset[19]
- synth, synth_lo, synth_hi: A set of 1M randomly generated strings following a uniform distribution of a-z characters at each position with characters having no correlation, low correlation, and high correlation with neighbouring ASCII values, respectively.

Overall, the experiment show that Learned Sort is also a very promising direction for sorting complex objects, such as strings. It should be noted, that building efficient models for string is still an active area of research and probably a paper on its own as it also have far reaching applications for indexes, tries, and many other data structures and algorithms. Finally, we would like to point out that if we include the training time with the sorting time, Learned Sort still dominates the other algorithms but by a margin of of  $2 - 8\%$  rather than the  $5 - 20\%$  shown in Figure 9.

# 6.5 The impact of duplicates

The number of duplicates (i.e., repeated keys) is a factor that affects the run-time behavior of our algorithm as our model will always assign the same position/bucket to the key, which increases the number of collisions and the number of keys placed into the spill bucket. To study the impact of duplicates, we first generate a normal distribution dataset  $(\mu = 0$  and  $\sigma = 5)$  and afterwards duplicate a few randomly selected keys n-times (referred to as spikes).

Figure 11 shows the performance of Learned Sort and the other baseline algorithms for different combinations of the