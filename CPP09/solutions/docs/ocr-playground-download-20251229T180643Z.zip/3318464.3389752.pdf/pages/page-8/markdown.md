Research 11: Machine Learning for Databases II

SIGMOD '20, June 14-19, 2020, Portland, OR, USA

![img-5.jpeg](img-5.jpeg)
Figure 6: Mapping time for various fan-out values (log scale)

the resulting prediction is not guaranteed to be monotonic, increasing the time that Insertion Sort takes at the end of Algorithm 2. One way to force the CDF model to be monotonic is to use boundary checks for the prediction ranges of each leaf model, however, this comes at the expense of additional branching instructions for every element and at every iteration of the loop in Line 10 of Algorithm 2.

Thus, we opted instead to train the models using linear spline fitting which has better monotonicity. Furthermore, this method is cheaper to compute than the closed-form of linear regression and only requires to fit a line between the min and max key in the respective training sets.

From the perspective of a single model, splines seem to fit much worse than other models. However, recall that we use several linear models as part of the RMI, which overall maintains a good level of approximation of the CDF even for highly skewed distributions. Therefore, in contrast to [29], using linear splines, provides bigger advantages because (1) it is on average  $2.7 \times$  faster to "train" than the closed-form version of linear regression, and (2) it provides up to  $35\%$  less key swaps during Insertion Sort.

# 3 ALGORITHM ANALYSIS

In this section we analyze the complexity and the performance of the algorithm w.r.t. various parameters.

# 3.1 Analysis of the sorting parameters

3.1.1 Choosing the fan-out  $(f)$ . One key parameter of our algorithm is the fan-out  $f$ . On one hand, we want to have a high fan-out, as it allows us to leverage the model's accuracy to the fullest extent. On the other hand, in order to utilize the cache in the optimal way, we have to restrict the number of buckets, as we otherwise can not ensure that we can append to a bucket without causing a cache miss. Ideally, for all buckets we would keep in cache the auxiliary data structures, as well as the next empty slot per bucket.

In order to understand this trade-off, we measured the performance of Learned Sort with varying fan-out values (Figure 6) using a random array of 100M doubles, which is large enough to not fit in any cache level. The minimum of this plot corresponds to the point where all the hot memory

locations fit in the L2 cache ( $f \approx 1 - 5\mathrm{K}$ ). Empirically, the fan-out value that gives the best trade-off for the particular cache size in this setup is 1K. Hence, like in the cache-efficient Radix-Sort implementation, this parameter has to be tuned based on the available cache size.

3.1.2 Choosing the threshold  $(t)$ . The threshold  $t$  determines the minimum bucket capacity as well as when to switch to a Counting Sort subroutine (Line 11 in Algorithm 2). We do this for two reasons: (1) to reduce the number of overflows (i.e., the number of elements in the spill bucket) and (2) to take better advantage of the model for the in-bucket sorting. Here we show how the threshold  $t$  affects the size of the spill bucket, which directly influences the performance.

If we had a perfect model every element would be mapped to a unique position. Yet, in most cases, this is impossible to achieve as we train based on a sample and aim to restrict the complexity of the model itself, inevitably mapping different items to the same position. Then our problem becomes that of randomly hashing  $N$  elements onto  $N$  unit-capacity buckets (i.e.,  $t = 1$ ). That is, the model that we learn behaves similar to an order-preserving hash function as a randomly generated element from this distribution is equally likely to be mapped onto any bucket. This holds for any distribution of the input array  $A$ , since its CDF function  $F_{A}$  will be uniformly distributed between [0, 1] [13]. Since we are using  $N$  buckets, the  $k^{\text{th}}$  bucket will contain the value range  $[(k - 1) / N, k / N)$  and the probability of the  $k^{\text{th}}$  bucket being empty is  $(1 - 1 / N)^{N}$ , which is approximately  $1 / e$  for large  $N$ . This means that approximately  $N / e$  buckets will be empty at the end of the mapping phase, and all of these elements will be placed in the spill bucket. Using  $s$  to denote the size of the spill bucket, we have  $\mathbf{E}[s] = N / e$ .

In the general case, our problem is that of randomly hashing  $N$  elements into  $N / t$  buckets, each with capacity  $t \geq 1$ . Then, the expected number of overflowing elements is:

$\mathbf{E}[s] = \frac{N}{te^t}\sum_{i = 0}^{t - 1}\frac{(t - i)\cdot(t)^i}{i!}$

|  Capacity | Overflow | Capacity | Overflow  |
| --- | --- | --- | --- |
|  1 | 36.7% | 25 | 7.9%  |
|  2 | 27.1% | 50 | 5.6%  |
|  5 | 17.5% | 100 | 3.9%  |
|  10 | 12.5% | 1000 | 1.3%  |

Table 1: Bucket capacity  $(t)$  vs. proportion of elements in the spill bucket  $(\mathbf{E}[s] / N)$ .

Table 1 represents the proportion of the elements in the spill bucket for various bucket capacities. Empirically, we found that we can maximize the performance of Learned Sort