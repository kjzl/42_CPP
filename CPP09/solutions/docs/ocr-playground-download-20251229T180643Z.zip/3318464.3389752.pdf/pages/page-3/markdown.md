Research 11: Machine Learning for Databases II

SIGMOD '20, June 14-19, 2020, Portland, OR, USA

![img-0.jpeg](img-0.jpeg)
Figure 1: Sorting with the perfect CDF model

experiments show that Learned Sort can indeed achieve better performance than highly tuned counting-based sorting algorithms, including Radix Sort and histogram-based sorts, as well as comparison-based and hybrid sorting algorithms. In fact, our learned sorting algorithm provides the best performance even when we include the model training time as a part of the overall sorting time. For example, our experiments show that Learned Sort yields an average of  $3.38 \times$  performance improvement over  $\mathrm{C}++$  STL sort (std::sort)[16],  $5.54 \times$  improvement over Timsort (Python's default sorting algorithm [45]),  $1.49 \times$  over Radix sort[51], and  $1.31 \times$  over  $\mathrm{IS}^4\mathrm{o}[2]$ , a cache-efficient version of the Samplesort and one of the fastest available sorting implementations [40].

In summary, we make the following contributions:

- We propose a first ML-enhanced sorting algorithm, called Learned Sort, which leverages simple ML models to model the empirical CDF to significantly speed-up a new variant of Radix Sort
- We theoretically analyze our sorting algorithm
- We exhaustively evaluate Learned Sort over various synthetic and real-world datasets

# 2 LEARNING TO SORT NUMBERS

Given a function  $F_{A}(x)$ , which returns the exact empirical CDF value for each key  $x \in A$ , we can sort  $A$  by calculating the position of each key within the sorted order as  $pos \gets F_{A}(x) \cdot |A|$ . This would allow us to sort a dataset with a single pass over the data as visualized in Figure 1.

However, in general, we will not have a perfect CDF function, especially if we train the model just based on a sample from the input data. In addition, there might be duplicates in the dataset, which may cause several keys to be mapped to the same position. In the following, we describe an initial learned sorting algorithm, similar to the one of SageDB[28], that is robust against imprecise models, and then explain why this first approach is still not competitive, before introducing the final algorithm. To simplify the discussion, our focus in this section is exclusively on the sorting of numbers and we only describe the out-of-place variant of our algorithm, in

Algorithm 1 A first Learned Sort
Input  $A$  - the array to be sorted
Input  $F_{A}$  - the CDF model for the distribution of  $A$
Input  $\sigma$  - the over-allocation rate, Default=1
Output  $A^{\prime}$  - the sorted version of array  $A$
1: procedure LEARNED-SORT(A,  $F_{A},\sigma$  )
2:  $N\gets A$  .length
3:  $A^{\prime}\gets$  empty array of size  $(N\cdot o)$
4: for  $x$  in  $A$  do
5: pos  $\leftarrow [F_A(x)\cdot N\cdot o]$
6: if EMPTY(A'[pos]) then  $A^{\prime}[pos]\gets x$
7: else COLLISION-HANDLEB(x)
8: if  $\sigma &gt;1$  then COMPACT(A')
9: if NON-MONOTONIC then INSERTION-SORT(A')
10: return  $A^{\prime}$

which we use an auxiliary array as big as the input array. Later, we discuss the changes necessary to create an in-place variant of the same algorithm in Section 4.1 and address the sorting of strings and other complex objects in Section 4.2.

# 2.1 Sorting with imprecise models

As discussed earlier, duplicate keys and imprecise models may lead to the mapping of multiple keys to the same output position in the sorted array. Moreover, some models (e.g., NN or even the Recursive Model Index (RMI) [29]) may not be able to guarantee monotonicity, creating small misplacements in the output. That is, for two keys  $a$  and  $b$  with  $a &lt; b$  the CDF value of  $a$  might be greater than the one of  $b$  ( $F(a) &gt; F(b)$ ), thus, causing the output to not be entirely sorted. Obviously, such errors should be small as otherwise using a model would provide no benefits. However, if the model does not guarantee monotonicity, further work on the output is needed to repair such errors. That is a learned sorting algorithm also has to (1) correct the sort order for non-monotonic models, (2) handle key collisions, and preferably (3) minimize the number of such collisions. A general algorithm for dealing with those three issues is outlined in Algorithm 1. The core idea is again simple: given a model we calculate the expected position for each key (Line 5) and, if that position in the output is free, place the key there (Line 6). In case the position is not empty, we have several options to handle the collisions (Line 7):

(1) Linear probing: If a position is already occupied, we could sequentially scan the array for the nearest empty spot and place the element there. However, this technique might misplace keys (like non-monotonic models) and will take increasingly more time as the array fills up.
(2) Chaining: Like in hash-tables, we could chain elements for already-filled positions. This could be implemented either with a linked list or variable-sized sub-arrays, both of which introduce additional performance overhead due to pointer chasing and dynamic memory allocation.