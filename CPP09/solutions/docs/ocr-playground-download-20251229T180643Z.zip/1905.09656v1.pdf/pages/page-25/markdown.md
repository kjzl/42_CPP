On the Average Case of MergeInsertion

average case we need to consider that in some cases $b_{i}$ can be inserted using just $k_{i} - 1$ comparisons. This is reflected by $\alpha_{m}$ and $\beta_{k}$, the first of which has already been studied by [4].

To estimate the cost of an insertion we use the formula $T_{\mathrm{InsAvg}}(m) = \lceil \log m \rceil + 1 - \frac{2^{\lceil \log m \rceil}}{m}$ by [4]. Technically this formula is only correct if the probability of an element being inserted is the same for each position. This is not the case with MergeInsertion. Instead the probability is monotonically decreasing with the index. Binary insertion can be implemented to take advantage of this property, as explained in Section 3, in which case $T_{\mathrm{InsAvg}}(m)$ acts as an upper bound on the cost of an insertion.

Using our result from above that on average $\frac{1}{4}$ of the elements are inserted in less than $2^{k} - 1 - \frac{2^{k-4}}{9} \pm \mathcal{O}(1)$ elements we can calculate $\beta_{k}$ as the difference of the cost of an insertion in the worst-case $(k)$ and in the average case.

$$
\begin{array}{l}
\beta_{k} \geq k - \left(\frac{3}{4} T_{\mathrm{InsAvg}} \left(2^{k}\right) + \frac{1}{4} T_{\mathrm{InsAvg}} \left(2^{k} - \frac{2^{k-6}}{3} \pm \mathcal{O}(1)\right)\right) \\
= k - \left(\frac{3}{4} \left(k + 1 - \frac{2^{k}}{2^{k}}\right) + \frac{1}{4} \left(k + 1 - \frac{2^{k}}{2^{k} - \frac{2^{k-6}}{3} \pm \mathcal{O}(1)}\right)\right) \\
= -1 + \frac{3}{4} + \frac{1}{4} \cdot \frac{1}{1 - \frac{1}{1 - \frac{2^{-6}}{3}} \pm \mathcal{O}(2^{-k})} \\
= -\frac{1}{4} + \frac{1}{4} \cdot \frac{1}{1 - \frac{1}{192}} \pm \mathcal{O}(2^{-k}) \\
= -\frac{1}{4} + \frac{1}{4} \cdot \frac{1}{\frac{191}{192}} \pm \mathcal{O}(2^{-k}) \\
= -\frac{1}{4} + \frac{1}{4} \cdot \frac{192}{191} \pm \mathcal{O}(2^{-k}) \\
= \frac{1}{764} \pm \mathcal{O}(2^{-k})
\end{array}
$$

Combining this with Appendix B.3 we can calculate the difference between the worst-case and the average-case as

$$
\begin{array}{l}
G_{\text{worst-case}}(m) - G_{\text{average-case}}(m) \\
= k_{m}(m - t_{k_{m}-1}) + \sum_{1 \leq k &lt; k_{m}} k(t_{k} - t_{k-1}) \\
\quad - (k_{m} - \alpha_{m})(m - t_{k_{m}-1}) - \sum_{1 \leq k &lt; k_{m}} (k - \beta_{k})(t_{k} - t_{k-1}) \\
= \alpha_{m}(m - t_{k_{m}-1}) + \sum_{1 \leq k &lt; k_{m}} \beta_{k}(t_{k} - t_{k-1}) \\
\geq \alpha_{m}(m - t_{k_{m-1}}) + \sum_{1 \leq k &lt; k_{m}} \left(\frac{1}{764} \pm \mathcal{O}(2^{-k})\right)(t_{k} - t_{k-1})
\end{array}
$$