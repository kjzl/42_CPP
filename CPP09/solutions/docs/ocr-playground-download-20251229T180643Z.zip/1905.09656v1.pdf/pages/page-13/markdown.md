On the Average Case of MergeInsertion

# References

- [1] Boehm, H.J., Atkinson, R., Plass, M.: Ropes: An alternative to strings. Softw. Pract. Exper. 25(12), 1315–1330 (Dec 1995)
- [2] Bui, T., Thanh, M.: Significant improvements to the Ford-Johnson algorithm for sorting. BIT Numerical Mathematics 25(1), 70–75 (1985)
- [3] Edelkamp, S., Weiß, A.: Quickxsort: Efficient Sorting with $n\log n-1.399n+o(n)$ Comparisons on Average. In: CSR 2014 Proc. pp. 139–152 (2014)
- [4] Edelkamp, S., Weiß, A., Wild, S.: Quickxsort - A fast sorting scheme in theory and practice. CoRR abs/1811.01259 (2018)
- [5] Ford, L.R., Johnson, S.M.: A tournament problem. The American Mathematical Monthly 66(5), 387–389 (1959)
- [6] Iwama, K., Teruyama, J.: Improved average complexity for comparison-based sorting. In: Workshop on Algorithms and Data Structures. pp. 485–496. Springer (2017)
- [7] Knuth, D.E.: The Art of Computer Programming, Volume 3: (2Nd Ed.) Sorting and Searching. Addison Wesley Longman, Redwood City, CA, USA (1998)
- [8] Manacher, G.K.: The Ford-Johnson sorting algorithm is not optimal. J. ACM 26(3), 441–456 (Jul 1979)
- [9] Peczarski, M.: New results in minimum-comparison sorting. Algorithmica 40(2), 133–145 (2004)
- [10] Peczarski, M.: The Ford-Johnson algorithm still unbeaten for less than 47 elements. Inf. Process. Lett. 101(3), 126–128 (2007)
- [11] Reinhardt, K.: Sorting *In-Place* with a *Worst Case* complexity of $n$ log $n$-1.3$n+O$(log$n$) comparisons and epsilon $n$ log $n+O$(1) transports. In: Algorithms and Computation, ISAAC ’92, Proc. pp. 489–498 (1992)
- [12] Stober, F.: Source code and generated data (2018), https://github.com/CodeCrafter47/merge-insertion