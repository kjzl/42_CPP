On the Average Case of MergeInsertion

![img-6.jpeg](img-6.jpeg)
(a) center-left

![img-7.jpeg](img-7.jpeg)
(b) center-right

![img-8.jpeg](img-8.jpeg)
(c) left
Fig. 4: Different strategies for binary insertion.

![img-9.jpeg](img-9.jpeg)
(d) right

insertion costs. We compare four different strategies all satisfying that the corresponding decision trees have their leaves distributed across at most two layers. For an example with five elements see Figure 4.

First there are the center-left and center-right strategies (the standard options for binary insertion): they compare the element to be inserted with the middle element, rounding down(up) in case of an odd number. The left strategy chooses the element to compare with in a way such that the positions where only  $k - 1$  comparisons are required are at the very left. The right strategy is similar, here the positions where one can insert with just  $k - 1$  comparisons are at the right. To summarize, the element to compare with is

|  |n+1/2 | strategy center-left  |
| --- | --- | --- |
|  |n+1/2 | strategy center-right  |
|  max{n-2k+1,2k-1} | strategy left  |
|  min{2k,n-2k-1+1} | strategy right  |

where  $k = \lfloor \log n \rfloor$ . Notice that the left strategy is also used in [6], where it is called right-hand-binary-search. Figure 5 shows experimental results comparing the different strategies for binary insertion regarding their effect on the average-case of MergeInsertion. As we can see the left strategy performs the best, closely followed by center-left and center-right. right performs the worst. The left strategy performing best is no surprise since the probability that an element is inserted into one of the left positions is higher than it being inserted to the right. Therefore, in all further experiments we use the left strategy.

# 4 Improved Upper Bounds for MergeInsertion

Numeric upper bound The goal of this section is to combine the probability given by Theorem 2 that an element  $b_{t_{k-1}+i}$  is inserted into  $j$  elements with an upper bound for the number of comparisons required for binary insertion.

By [4], the number of comparisons required for binary insertion when inserting into  $m - 1$  elements is  $T_{\mathrm{InsAvg}}(m) = \lceil \log m \rceil + 1 - \frac{2^{\lceil \log m \rceil}}{m}$ . While only being exact in case of a uniform distribution, this formula acts as an upper bound in our case, where the probability is monotonically decreasing with the index.

This leads to an upper bound for the cost of inserting  $b_{t_{k-1}+i}$  of  $T_{\mathrm{Ins}}(i,k) = \sum_j P(Y_i = j) \cdot T_{\mathrm{InsAvg}}(j+1)$ . From there we calculated an upper bound for MergeInsertion. Figure 6 compares those results with experimental data on the number of comparisons required by MergeInsertion. We observe that the difference is rather small.