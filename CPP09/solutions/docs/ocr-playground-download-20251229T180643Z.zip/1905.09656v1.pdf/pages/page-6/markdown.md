Florian Stober and Armin Weiβ

![img-4.jpeg](img-4.jpeg)
Fig. 2: Probability distribution of  $Y_{i}$ . Fig. 3: Mean of  $Y_{i}$  for different  $i$ .  $k = 7$ .

![img-5.jpeg](img-5.jpeg)

$$
+ P \left(X _ {i + q} \geq 2 t _ {k - 1} + i \mid \tilde {Y} _ {i, q - 1} = j\right) \cdot P \left(\tilde {Y} _ {i, q - 1} = j\right)
$$

The probability  $P(X_{i + q} &lt; 2t_{k - 1} + i \mid \tilde{Y}_{i,q - 1} = j - 1)$  can be obtained by looking at Fig. 1 and counting elements. When  $b_{t_{k - 1} + i + q}$  is inserted, the elements on the main chain which are smaller than  $a_{t_{k - 1} + i}$  are  $x_{1}$  to  $x_{2t_{k - 1}}$ ,  $a_{t_{k - 1} + 1}$  to  $a_{t_{k - 1} + i - 1}$  and  $j - 1$  elements out of  $\{b_{t_{k - 1} + i + 1},\ldots ,b_{t_{k - 1} + i + q - 1}\}$  which is a total of  $2t_{k - 1} + 2i + j - 2$  elements. Combined with the fact that the main chain consists of  $2t_{k - 1} + 2i + 2q - 2$  elements smaller than  $a_{t_{k - 1} + i + q}$  we obtain the probability  $\frac{2t_{k - 1} + 2i + j - 1}{2t_{k - 1} + 2i + 2q - 1}$ . We can calculate  $P(X_{i + q} \geq 2t_{k - 1} + i \mid \tilde{Y}_{i,q - 1} = j)$  similarly leading to

$$
P (\tilde {Y} _ {i, q} = j) = \frac {2 t _ {k - 1} + 2 i + j - 1}{2 t _ {k - 1} + 2 i + 2 q - 1} \cdot P (\tilde {Y} _ {i, q - 1} = j - 1) + \frac {2 q - j - 1}{2 t _ {k - 1} + 2 i + 2 q - 1} \cdot P (\tilde {Y} _ {i, q - 1} = j).
$$

By solving the recurrence, we obtain a closed form for  $P(\tilde{Y}_{i,q} = j)$  and, thus, for  $P(Y_{i} = j)$ . The complete proof is given in Appendix B.2.

Theorem 2. For  $1 \leq i \leq t_k - t_{k-1}$  and  $2t_{k-1} + i - 1 \leq j \leq 2^k - 1$  the probability  $P(Y_i = j)$ , that  $b_{t_{k-1} + i}$  is inserted into  $j$  elements is given by

$$
P (Y _ {i} = j) = 2 ^ {j - 2 t _ {k - 1} - i + 1} \frac {(2 t _ {k} - i - j - 1) !}{(j - 2 t _ {k - 1} - i + 1) ! (2 ^ {k} - j - 1) !} \frac {(i + j) !}{(2 t _ {k} - 1) !} \frac {(t _ {k} - 1) !}{(t _ {k - 1} + i - 1)}.
$$

Figure 2 shows the probability distribution for  $Y_{1}$ ,  $Y_{21}$  and  $Y_{42}$  where  $k = 7$ .  $Y_{42}$  corresponds to the insertion of  $b_{t_k}$  (the first element of the batch).  $Y_{1}$  corresponds to the insertion of  $b_{t_{k-1}+1}$  (the last element of the batch). In addition to those three probability distributions Fig. 3 shows the mean of all  $Y_{i}$  for  $k = 7$ .

Binary Insertion and different decision trees The Binary Insertion step is an important part of MergeInsertion. In the average case many elements are inserted in less than  $2^{k} - 1$  (which is the worst case). This leads to ambiguous decision trees where at some positions inserting an element requires only  $k - 1$  instead of  $k$  comparisons. Since not all positions are equally likely (positions on the left have a slightly higher probability), this results in different average