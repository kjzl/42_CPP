On the Average Case of MergeInsertion

![img-17.jpeg](img-17.jpeg)
Fig. 11: Comparison of different factors  $f$  for  $\hat{t}_k$ .

worst case). As we have seen in previous sections many elements are inserted into slightly less than  $2^k - 1$  elements. The idea behind increasing  $t_k$  by a constant factor  $f$  is to allow more elements to be inserted into close to  $2^k - 1$  elements.

Figure 10 shows how different factors  $f$  affect the number of comparisons required by MergeInsertion. The different lines represent different input lengths. For instance,  $n = 21845$  is an input size for which MergeInsertion works best. An overview of the different input lengths and how original MergeInsertion performs for these can be seen in Figure 9. The chosen values are assumed to be representative for the entire algorithm. We observe that for all shown input lengths, multiplying  $t_k$  by a factor  $f$  between 1.02 and 1.05, leads to an improvement.

Figure 11 compares different factors from 1.02 to 1.05. The factor 1.0 (i.e., the original algorithm) is included as a reference. We observe that all the other factors lead to a considerable improvement compared to 1.0. The difference between the factors in the chosen range is rather small. However, 1.03 appears to be best out of the tested values. At  $n \approx 2^k / 3$  the difference to the information-theoretic lower bound is reduced to  $0.007n$ , improving upon the original algorithm, which has a difference of  $0.01n$  to the optimum.

Another observation we make from Figure 11 is that the plot periodically repeats itself with each power of two. Thus, we conclude that replacing  $t_k$  with  $\hat{t}_k = \lfloor f \cdot t_k \rfloor$  with  $f \in [1.02, 1.05]$  reduces the number of comparisons required per element by some constant.

Combination with (1,2)-Insertion (1,2)-Insertion is a sorting algorithm presented in [6]. It works by inserting either a single element or two elements at once into an already sorted list. On its own (1,2)-Insertion is worse than MergeInsertion; however, it can be combined with MergeInsertion. The combined algorithm works by sorting  $m = \max \{u_k \mid u_k \leq n\}$  elements with MergeInsertion. Then the remaining elements are inserted using (1,2)-Insertion. Let  $u_k = \left\lfloor \left(\frac{4}{3}\right) 2^k \right\rfloor$  denote a point where MergeInsertion is optimal.

In Fig. 12 we can see that at the point  $u_{k}$  MergeInsertion and the combined algorithm perform the same. However, in the values following  $u_{k}$  the combined algorithm surpasses MergeInsertion until at one point close to the next optimum