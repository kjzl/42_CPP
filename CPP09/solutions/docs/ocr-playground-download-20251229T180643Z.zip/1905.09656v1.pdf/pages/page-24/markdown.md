Florian Stober and Armin Weiβ

By using the approximation $P(Y_{u} = j) \approx p(j)$ we can calculate a lower bound for the median of $Y_{\frac{t_k - t_{k-1}}{2}}$

$$
\begin{array}{l}
2^{k} - 1 - \left\lfloor n_{B} \cdot p_{B} \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \left\lceil \frac{t_{k} - t_{k-1}}{4} \right\rceil \frac{\left\lfloor \frac{t_{k} - t_{k-1}}{4} \right\rfloor}{2 t_{k} - 1} \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \left(\frac{2^{k-2} + (-1)^{k} - 3}{3} + \frac{1}{2} (-1)^{k} + \frac{1}{2}\right) \left(\frac{2^{k-2} + (-1)^{k} - 3}{3} + \frac{1}{2} (-1)^{k} - \frac{1}{2}\right) \frac{1}{2 t_{k} - 1} \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \left(\frac{2^{k-2}}{3} + \frac{1}{6} (-1)^{k} + \frac{1}{2}\right) \left(\frac{2^{k-2}}{3} + \frac{1}{6} (-1)^{k} - \frac{1}{2}\right) \frac{1}{2 t_{k} - 1} \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \left(\frac{2^{2k-4}}{9} + \frac{2^{k-2}}{9} (-1)^{k} + \frac{1}{36} - \frac{1}{4}\right) \frac{1}{2 t_{k} - 1} \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \left(\frac{2^{2k-4}}{9} + \frac{2^{k-2}}{9} (-1)^{k} + \frac{1}{36} - \frac{1}{4}\right) \left(\frac{1}{2 \frac{2^{k+1} + (-1)^{k}}{3} - 1}\right) \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \left(\frac{2^{2k-4}}{9} + \frac{2^{k-2}}{9} (-1)^{k} + \frac{1}{36} - \frac{1}{4}\right) \left(\frac{1}{2 \frac{2^{k+1}}{3}} \pm \mathcal{O}(2^{-k})\right) \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \left(\frac{2^{2k-4}}{9} + \frac{2^{k-2}}{9} (-1)^{k} + \frac{1}{36} - \frac{1}{4}\right) \frac{1}{2 \frac{2^{k+1}}{3}} \pm \mathcal{O}(1) \right\rfloor \\
= 2^{k} - 1 - \left\lfloor \frac{2^{k-6}}{3} + \frac{1}{3} (-1)^{k} \right\rfloor \pm \mathcal{O}(1) \Bigg\rfloor \\
\in 2^{k} - 1 - \frac{2^{k-6}}{3} + \mathcal{O}(1)
\end{array}
$$

This tells us that with a probability $\geq 50\%$, $b_{t_{k-1} + u}$ is inserted into $2^k - 1 - \frac{2^{k-6}}{3} \pm \mathcal{O}(1)$ or less elements. In conclusion all $b_i$ with $i \leq u = \frac{t_k - t_{k-1}}{2}$ are inserted into less than $2^k - 1 - \frac{2^{k-6}}{3} \pm \mathcal{O}(1)$ elements with a probability $\geq 50\%$.

Using that result we can calculate a better upper bound for the average case performance of the entire algorithm.

According to Knuth [7] in its worst case MergeInsertion requires $W(n) = n\log n - (3 - \log 3)n + n(y + 1 - 2^y) + \mathcal{O}(\log n)$ comparisons where $y = y(n) = \lceil \log (3n / 4) \rceil - \log (3n / 4) \in [0,1)$.

We calculate the number of comparisons required in the average case in a similar fashion to [4]. Recall Eq. (1) which is the number of comparisons required by the algorithm.

$$
F(n) = \left\lfloor \frac{n}{2} \right\rfloor + F\left(\left\lfloor \frac{n}{2} \right\rfloor\right) + G\left(\left\lceil \frac{n}{2} \right\rceil\right)
$$

$G(m)$ corresponds to the work done in the third step of the algorithm and is given by

$$
G(m) = (k_{m} - \alpha_{m})(m - t_{k_{m}-1}) + \sum_{1 \leq k &lt; k_{m}} (k - \beta_{k})(t_{k} - t_{k-1})
$$

where $t_{k_m - 1} \leq m &lt; t_{k_m}$ and $\alpha_{m}, \beta \in [0,1]$. Inserting an element $b_i$ with $t_{k_{i-1}} &lt; i \leq t_{k_i}$ requires at most $k_i$ comparisons. However, since we are looking at the