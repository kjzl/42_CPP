Florian Stober and Armin Weiβ

![img-25.jpeg](img-25.jpeg)
Fig. 17: Configuration where one batch is to be inserted.

i.e.  $P(Y_{q} &lt; m) \geq P(Y_{u} &lt; m)$ . This is because when  $b_{t_{k-1}+i}$  is inserted into  $m$  elements, then no matter which position it is inserted into, the next element,  $b_{t_{k-1}+i-1}$ , is inserted into at most  $m$  elements.

However Theorem 2 is hard to work with, so we approximate it with a binomial distribution. For a given  $k$  let  $d = t_k - t_{k-1}$  be the number of elements that are inserted as part of the batch. This configuration is illustrated in Fig. 17. Remember  $u = \frac{t_k - t_{k-1}}{2} = \frac{d}{2}$ . To calculate into how many elements  $b_{t_{k-1} + u} = b_{t_{k-1} + \frac{d}{2}}$  is inserted, we ask how many elements out of  $b_{t_{k-1} + \left\lfloor \frac{3}{4} d \right\rfloor}$  to  $b_{t_k}$  (marked as section B in Fig. 17) are inserted between  $a_{t_{k-1} + \frac{d}{2} + 1}$  and  $a_{t_{k-1} + \left\lfloor \frac{3}{4} d \right\rfloor - 1}$  (marked as section A).

The rationale is that for each element from section B that is inserted into section A,  $b_{t_{k-1} + u}$  is inserted into one less element. As a lower bound for the probability that an element from section B is inserted into one of the positions in section A we use the probability that  $b_{t_k}$  is inserted between  $a_{t_k - 1}$  and  $a_{t_k}$  which is  $\frac{1}{2t_k - 1}$ .

That is because if we assume that all  $b_{i}$  with  $i &lt; t_{k}$  are inserted before inserting  $b_{t_k}$ , then  $b_{t_k}$  is inserted into  $2t_{k} - 2$  elements, so the probability for each position is  $\frac{1}{2t_k - 1}$ . Since none of the  $b_{i}$  with  $i &lt; t_{k}$  can be inserted between  $a_{t_k - 1}$  and  $a_{t_k}$  because they are all smaller than  $a_{t_k - 1}$ , the probability that  $b_{t_k}$  is inserted between  $a_{t_k - 1}$  and  $a_{t_k}$  does not change when we insert it first as the algorithm demands.

To calculate the probability that an element  $b_{t_k - q}$  with  $q &gt; 0$  is inserted into the rightmost position we assume that all  $b_i$  with  $i &lt; t_k - q$  are inserted before inserting  $b_{t_k - q}$ . Then  $b_{t_k - q}$  is inserted into at most  $2t_k - q - 2$  elements, i.e., the elements  $x_1$  to  $x_{2t_k - 1}$ ,  $a_{t_k - 1 + 1}$  to  $a_{t_k - q - 1}$ ,  $b_{t_k - 1 + 1}$  to  $b_{t_k - q - 1}$  and at most  $q$  elements out of  $b_{t_k - q + 1}$  to  $b_{t_k}$ .

Hence the probability for each position is greater than  $\frac{1}{2t_k - q - 1}$  which is greater than  $\frac{1}{2t_k - 1}$ . Since none of the  $b_i$  with  $i &lt; t_k - q$  can be inserted to the right of  $a_{t_k - q - 1}$ , the probability that  $b_{t_k} - q$  is inserted into any of the positions between  $a_{t_k - q - 1}$  and  $a_{t_k - q}$  remains unchanged when inserting the elements in the correct order.

The probability that an element is inserted at a specific position is monotonically decreasing with the index. This is because if an element  $b_{i}$  is inserted to the left of an element  $a_{i - h}$  then  $b_{i - h}$  is inserted into one more element than it would be if  $b_{i}$  had been inserted to the right of  $a_{i - h}$ . As a result any position