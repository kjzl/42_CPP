Florian Stober and Armin Weiß

For the second case we have

$$
\begin{aligned}
&amp; \left(\prod_{l=j-2t_{k-1}+1}^{i-1} 2t_{k-1} + 2l\right) \cdot \left(\prod_{l=j-2t_{k-1}+1}^{i} (2t_{k-1} + 2l - 1)\right)^{-1} \\
&amp; = \left(\prod_{l=j-t_{k-1}+1}^{t_{k-1}+i-1} 2l\right) \cdot \left(\prod_{l=2j-2t_{k-1}+1}^{2t_{k-1}+2i-1} l\right)^{-1} \cdot \left(\prod_{l=j-t_{k-1}+1}^{t_{k-1}+i-1} 2l\right) \\
&amp; = \left(\prod_{l=1}^{t_{k-1}+i-1} 2l\right) \cdot \left(\prod_{l=1}^{j-t_{k-1}} 2l\right)^{-1} \cdot \left(\prod_{l=1}^{2t_{k-1}+2i-1} l\right)^{-1} \tag{4} \\
&amp; \quad \cdot \left(\prod_{l=1}^{2j-2t_{k-1}} l\right) \cdot \left(\prod_{l=1}^{t_{k-1}+i-1} 2l\right) \cdot \left(\prod_{l=1}^{j-t_{k-1}} 2l\right)^{-1} \\
&amp; = 2^{4t_{k-1}-2j+2i-2} \left(\frac{(t_{k-1}+i-1)!}{(j-t_{k-1})!}\right)^2 \frac{(2j-2t_{k-1})!}{(2t_{k-1}+2i-1)!}
\end{aligned}
$$

By substitution of (3) and (4) in (2) we obtain Theorem 1.

## B.2 Proof of Theorem 2

![img-24.jpeg](img-24.jpeg)
Fig. 16: Configuration where one batch of $t_k - t_{k-1}$ elements remains to be inserted. The elements $b_{t_{k-1}+i}$ and $b_{t_{k-1}+i+q}$ are drawn.

Recall the definitions of $Y_{i}$, $\tilde{Y}_{i,q}$ and their relation:

$$
Y_{i}: \omega \mapsto \left| \left\{v \in \left\{x_{1}, \dots, x_{2^{k}} \right\} \cup \left\{b_{t_{k-1}+i+1}, \dots, b_{t_{k}} \right\} \mid \omega(v) &lt; \omega(a_{t_{k-1}+i}) \right\} \right| \tag{5}
$$

$$
\tilde{Y}_{i,q}: \omega \mapsto \left| \left\{v \in \left\{b_{t_{k-1}+i+1}, \dots, b_{t_{k-1}+i+q} \right\} \mid \omega(v) &lt; \omega(a_{t_{k-1}+i}) \right\} \right| \tag{6}
$$

$$
Y_{i} = \tilde{Y}_{i,t_{k}-t_{k-1}-i} + 2t_{k-1} + i - 1 \tag{7}
$$