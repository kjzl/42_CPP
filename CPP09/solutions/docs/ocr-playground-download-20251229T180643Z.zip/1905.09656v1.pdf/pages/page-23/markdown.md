On the Average Case of MergeInsertion

further to the left is more likely than the right-most position, so we can use that as a lower bound.

There are $\left\lfloor \frac{d}{4} \right\rfloor - 1$ elements in section A, i.e., there are at least $\left\lfloor \frac{d}{4} \right\rfloor$ positions where an element can be inserted. Hence the probability that an element from section B is inserted into section A is at least $\frac{\left\lfloor \frac{d}{4} \right\rfloor}{2t_k - 1}$ and consequently the probability that it is not inserted before $b_{t_{k-1} + u}$ is at least $\frac{\left\lfloor \frac{d}{4} \right\rfloor}{2t_k - 1}$. That is because all positions part of section A are after $a_{t_{k-1} + u}$.

Section B contains $\left\lceil \frac{d}{2} \right\rceil$ elements. Using that and substituting $u = \frac{d}{2}$ we obtain the binomial distribution with the parameters $n_B = \left\lceil \frac{u}{2} \right\rceil$ and $p_B = \frac{\left\lfloor \frac{d}{4} \right\rfloor}{2t_k - 1}$. As a result we have

$$
p(j) = \binom{\left\lceil \frac{u}{2} \right\rceil}{q} \left(\frac{\left\lfloor \frac{u}{2} \right\rfloor}{2t_k - 1}\right)^q \left(\frac{2t_k - 1 - \left\lfloor \frac{u}{2} \right\rfloor}{2t_k - 1}\right)^{\left\lceil \frac{u}{2} \right\rceil - q} \tag{17}
$$

with $q = 2^k - 1 - j$, that by construction fulfills the property given in Equation (18) for all $j_0$.

$$
\sum_{j = 0}^{j_0} p(j) \leq \sum_{j = 0}^{j_0} P(Y_u = j) = P(Y_u \leq j_0) \tag{18}
$$

Fig. 18 compares our approximation $p(j)$ with real distribution $P(Y_u = j)$. We observe that the maximum of our approximation is further to the right than the one of the real distribution.

![img-26.jpeg](img-26.jpeg)
Fig. 18: Difference between the real distribution and our approximation for $k = 8$ and $u = 43$.