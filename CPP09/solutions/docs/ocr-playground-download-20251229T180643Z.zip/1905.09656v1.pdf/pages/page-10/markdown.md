Florian Stober and Armin Weiß

![img-14.jpeg](img-14.jpeg)
Fig. 8: Plot of  $c(x)$ .

![img-15.jpeg](img-15.jpeg)
Fig. 9:  $n$  used in Fig. 10.

![img-16.jpeg](img-16.jpeg)
Fig. 10: Effects of replacing  $t_k$  with  $\hat{t}_k$ .

for  $1 \leq i \leq u$  are inserted in  $\frac{2^{k-6}}{3}$  elements less compared to the worst case. Combining that with the bounds from [4] we obtain Theorem 3. The complete proof is given in Appendix B.3.

# 5 Experiments

In this section we discuss our experiment, which consist of two parts: first, we evaluate how increasing  $t_k$  by some constant factor can reduce the number of comparisons, then we examine how the combination with the (1,2)-Insertion algorithm as proposed in [6] improves MergeInsertion.

We implemented MergeInsertion using a tree based data structure, similar to the Rope data structure[1] used in text processing, resulting in a comparably "fast" implementation. Implementation details can be found in Appendix D. All experiments use the left strategy for binary insertion (see Section 3). The number of comparisons has been averaged over 10 to 10000 runs, depending on the size of the input.

Increasing  $t_k$  by a Constant Factor In this section we modify MergeInsertion by replacing  $t_k$  with  $\hat{t}_k = \lfloor f \cdot t_k \rfloor$  - otherwise the algorithm is the same. Originally the numbers  $t_k$  have been chosen, such that each element  $b_i$  with  $t_{k-1} &lt; i \leq t_k$  is inserted into at most  $2^k - 1$  elements (which is optimal for the