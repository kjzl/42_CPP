Florian Stober and Armin Weiß

# D Implementing MergeInsertion

To perform experiments we first need to implement the algorithm. For the purpose of our implementation we assume that each element is unique. This condition is easy to fulfill for synthetic test data. You can see our implementation in Algorithm 5. We now go over some of the key challenges when implementing MergeInsertion.

Algorithm 5 MergeInsertion
1: procedure MERGEINSERTION(d: array of  $n$  elements)
2: Step 1: Pairwise comparison
3: for all  $1 \leq i \leq \left\lfloor \frac{n}{2} \right\rfloor$  do ▷ Split into larger and smaller half
4:  $a_i \gets \max \left\{d_i, a_{i + \left\lfloor \frac{n}{2} \right\rfloor} \right\}$
5:  $b_i \gets \min \left\{d_i, a_{i + \left\lfloor \frac{n}{2} \right\rfloor} \right\}$
6: end for
7: if  $n \mod 2 = 1$  then
8:  $b_{\left\lceil \frac{n}{2} \right\rceil} \gets d_n$
9: end if
10: Step 2: Recursion and Renaming
11:  $m \gets \{(a_i, b_i) \mid 1 \leq i \leq \left\lfloor \frac{n}{2} \right\rfloor \}$ ▷ Store mapping
12:  $a \gets \text{MERGEINSERTION}(a)$
13: for all  $1 \leq i \leq \left\lfloor \frac{n}{2} \right\rfloor$  do ▷ Permute smaller half
14:  $b_i \gets e$  where  $(a_i, e) \in m$
15: end for
16: Step 3: Insertion
17:  $d \gets b_1, a_1, \ldots, a_{\left\lfloor \frac{n}{2} \right\rfloor}$
18:  $k \gets 2$
19: while  $t_{k-1} &lt; \left\lceil \frac{n}{2} \right\rceil$  do
20:  $m \gets \min \left\{t_k, \left\lceil \frac{n}{2} \right\rceil \right\}$ ▷ first element of the batch
21:  $u \gets t_{k-1} + m$ ▷ position of  $a_m$  in  $d$
22: for  $i$  in  $m$  down to  $t_{k-1} + 1$  do
23:  $d \gets \text{BINARYINSERTION}(b_i, d_1, \ldots, d_{u-1}), d_u, \ldots, d_{2m + t_{k-1}-i}$
24: while  $d_u \neq a_{i-1}$  do ▷ adjust  $u$
25:  $u \gets u - 1$
26: end while
27: end for
28:  $k \gets k + 1$
29: end while
30: return  $d$
31: end procedure

1. MergeInsertion requires elements to be inserted into arbitrary positions. When using a simple array to store the elements this operation requires moving  $\mathcal{O}(n)$  elements. Since MergeInsertion inserts each element exactly