Florian Stober and Armin Weiß

![img-23.jpeg](img-23.jpeg)
Fig. 15: Comparing experimental results with the upper bound from Theorem 3.