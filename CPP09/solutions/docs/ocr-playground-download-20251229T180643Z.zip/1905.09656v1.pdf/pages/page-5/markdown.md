On the Average Case of MergeInsertion

Let us look at where an element will end up after it has been inserted. Not all positions are equally likely. For this purpose we define the random variable  $X_{i}$  as follows. To simplify notation we define  $x_{t_{k - 1} + j} \coloneqq a_{j}$  for  $t_{k - 1} &lt; j \leq t_{k}$  (hence, the main chain consists of  $x_{1},\ldots ,x_{2^{k}}$ ).

$$
X _ {i}: \omega \mapsto \left\{ \begin{array}{l l} 0 &amp; \text {i f} \omega (b _ {t _ {k - 1} + i}) &lt;   \omega (x _ {1}) \\ j &amp; \text {i f} \omega (x _ {j}) &lt;   \omega (b _ {t _ {k - 1} + i}) &lt;   \omega (x _ {j + 1}) \text {f o r} j \in \{1, \ldots , 2 ^ {k} - 2 \} \\ 2 ^ {k} - 1 &amp; \text {i f} \omega (x _ {2 ^ {k} - 1}) &lt;   \omega (b _ {t _ {k - 1} + i}). \end{array} \right.
$$

We are interested in the probabilities  $P(X_{i} = j)$ . These values follow a simple pattern (for  $k = 4$  these are given in Table 2 in the appendix).

Theorem 1. The probability of  $b_{t_{k-1} + i}$  being inserted between  $x_j$  and  $x_{j+1}$  is given by

$$
P (X _ {i} = j) = \left\{ \begin{array}{l l} 2 ^ {2 i - 2} \left(\frac {(t _ {k - 1} + i - 1) !}{(t _ {k - 1}) !}\right) ^ {2} \frac {(2 t _ {k - 1}) !}{(2 t _ {k - 1} + 2 i - 1) !} &amp; \text {i f} 0 \leq j \leq 2 t _ {k - 1} \\ 2 ^ {4 t _ {k - 1} - 2 j + 2 i - 2} \left(\frac {(t _ {k - 1} + i - 1) !}{(j - t _ {k - 1}) !}\right) ^ {2} \frac {(2 j - 2 t _ {k - 1}) !}{(2 t _ {k - 1} + 2 i - 1) !} &amp; \text {i f} 2 t _ {k - 1} &lt;   j &lt;   2 t _ {k - 1} + i \\ 0 &amp; \text {o t h e r w i s e} \end{array} \right.
$$

Next, our aim is to compute the probability that  $b_{i}$  is inserted into a particular number of elements. This is of particular interest because the difference between average and worst case comes from the fact that sometimes we insert into less than  $2^{k} - 1$  elements. For that purpose we define the random variable  $Y_{i}$ .

$$
Y _ {i}: \omega \mapsto \left| \left\{v \in \left\{x _ {1}, \dots , x _ {2 ^ {k}} \right\} \cup \left\{b _ {t _ {k - 1} + i + 1}, \dots , b _ {t _ {k}} \right\} \mid \omega (v) &lt;   \omega \left(a _ {t _ {k - 1} + i}\right) \right\} \right|
$$

The elements in the main chain when inserting  $b_{t_k + i}$  are  $x_1$  to  $x_{2t_{k - 1} + i - 1}$  and those elements out of  $b_{t_{k - 1} + i + 1},\ldots ,b_{t_k}$  which have been inserted before  $a_{t_{k - 1} + i}$  (which is  $x_{2t_{k - 1} + i}$ ). For computing the number of these, we introduce random variables  $\tilde{Y}_{i,q}$  counting the elements in  $\{b_{t_{k - 1} + i + 1},\dots ,b_{t_{k - 1} + i + q}\}$  that are inserted before  $a_{t_{k - 1} + i}$ :

$$
\tilde {Y} _ {i, q}: \omega \mapsto \left| \left\{v \in \left\{b _ {t _ {k - 1} + i + 1}, \dots , b _ {t _ {k - 1} + i + q} \right\} \mid \omega (v) &lt;   \omega \left(a _ {t _ {k - 1} + i}\right) \right\} \right|.
$$

By setting  $q = t_k - t_{k-1} - i$ , we obtain  $Y_i = \tilde{Y}_{i,t_k - t_{k-1} - i} + 2t_{k-1} + i - 1$ . For an illustration see Figure 16 in the appendix. Clearly we have  $P\big(\tilde{Y}_{i,0} = j\big) = 1$  if  $j = 0$  and  $P\big(\tilde{Y}_{i,0} = j\big) = 0$  otherwise. For  $q &gt; 0$  there are two possibilities:

1.  $\tilde{Y}_{i,q - 1} = j - 1$  and  $X_{i + q} &lt; 2t_{k - 1} + i$ : out of  $\{b_{t_{k - 1} + i + 1},\ldots ,b_{t_{k - 1} + i + q - 1}\}$  there have been  $j - 1$  elements inserted before  $a_{t_{k - 1} + i}$  and  $b_{t_{k - 1} + i + q}$  is inserted before  $a_{t_{k - 1} + i}$ .
2.  $\tilde{Y}_{i,q - 1} = j$  and  $X_{i + q}\geq 2t_{k - 1} + i$ : out of  $\{b_{t_{k - 1} + i + 1},\ldots ,b_{t_{k - 1} + i + q - 1}\}$  there have been  $j$  elements inserted before  $a_{t_{k - 1} + i}$  and  $b_{t_{k - 1} + i + q}$  is inserted after  $a_{t_{k - 1} + i}$ .

From these we obtain the following recurrence:

$$
P (\tilde {Y} _ {i, q} = j) = P (X _ {i + q} &lt;   2 t _ {k - 1} + i \mid \tilde {Y} _ {i, q - 1} = j - 1) \cdot P (\tilde {Y} _ {i, q - 1} = j - 1)
$$