Florian Stober and Armin Weiß

From that we can calculate

$$
\begin{array}{l}
P \left(X _ {i + q} \geq 2 t _ {k - 1} + i \mid Y _ {i, q - 1} = d\right) \\
= 1 - P \left(X _ {i + q} &lt; 2 t _ {k - 1} + i \mid Y _ {i, q - 1} = d\right) \\
= 1 - \frac {2 t _ {k - 1} + 2 i + d}{2 t _ {k - 1} + 2 i + 2 q - 1} \tag {12} \\
= \frac {2 t _ {k - 1} + 2 i + 2 q - 1 - 2 t _ {k - 1} - 2 i - d}{2 t _ {k - 1} + 2 i + 2 q - 1} \\
= \frac {2 q - d - 1}{2 t _ {k - 1} + 2 i + 2 q - 1}
\end{array}
$$

Now we have all the necessary ingredients to proof Eq. (8) using induction.

1. Proof of Eq. (8) where $j = 0$ using $\tilde{Y}_{i,q} = 0 \Leftrightarrow X_{i + q} \geq 2t_{k - 1} + i \wedge \tilde{Y}_{i,q - 1} = 0$

$$
\begin{array}{l}
P \left(X _ {i + q} \geq 2 t _ {k - 1} + i \wedge \tilde {Y} _ {i, q - 1} = 0\right) \\
= P \left(X _ {i + q} \geq 2 t _ {k - 1} + i \mid \tilde {Y} _ {i, q - 1} = 0\right) \cdot P \left(\tilde {Y} _ {i, q - 1} = 0\right)
\end{array}
$$

$$
\begin{array}{l}
\stackrel {2. (1 2)} {=} \frac {2 q - 1}{2 t _ {k - 1} + 2 i + 2 q - 1} \cdot \frac {(2 q - 2) !}{2 ^ {q - 1} 0 ! (q - 1) !} 2 ^ {q - 1} \frac {(2 t _ {k - 1} + 2 i - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 3) !} \frac {(t _ {k - 1} + i + q - 2) !}{(t _ {k - 1} + i - 1) !} \\
= (2 q - 1) \left(2 t _ {k - 1} + 2 i + 2 q - 2\right) \cdot \frac {(2 q - 2) !}{2 ^ {q - 1} 0 ! (q - 1) !} 2 ^ {q - 1} \frac {(2 t _ {k - 1} + 2 i - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 2) !}{(t _ {k - 1} + i - 1) !} \\
= (2 q - 1) 2 \left(t _ {k - 1} + i + q - 1\right) \cdot \frac {(2 q - 2) !}{2 ^ {q} 0 ! (q - 1) !} 2 ^ {q} \frac {(2 t _ {k - 1} + 2 i - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 2) !}{(t _ {k - 1} + i - 1) !} \\
= (2 q - 1) 2 \cdot \frac {(2 q - 2) !}{2 ^ {q} 0 ! (q - 1) !} 2 ^ {q} \frac {(2 t _ {k - 1} + 2 i - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 1) !}{(t _ {k - 1} + i - 1) !} \\
= (2 q - 1) 2 \cdot \frac {q}{(2 q) (2 q - 1)} \cdot \frac {(2 q - 0) !}{2 ^ {q} 0 ! (q - 0) !} 2 ^ {q} \frac {(2 t _ {k - 1} + 2 i - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 1) !}{(t _ {k - 1} + i - 1) !} \\
= \frac {(2 q - 0) !}{2 ^ {q} 0 ! (q - 0) !} 2 ^ {q} \frac {(2 t _ {k - 1} + 2 i - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 1) !}{(t _ {k - 1} + i - 1) !} \\
= P \left(\tilde {Y} _ {i, q} = 0\right) \tag {13}
\end{array}
$$

2. Proof of Eq. (8) where $j = q$ using $\tilde{Y}_{i,q} = q \Leftrightarrow X_{i + q} &lt; 2t_{k - 1} + i \wedge \tilde{Y}_{i,q - 1} = q - 1$

$$
\begin{array}{l}
P \left(X _ {i + q} &lt; 2 t _ {k - 1} + i \wedge \tilde {Y} _ {i, q - 1} = q - 1\right) \\
= P \left(X _ {i + q} &lt; 2 t _ {k - 1} + i \mid \tilde {Y} _ {i, q - 1} = q - 1\right) \cdot P \left(\tilde {Y} _ {i, q - 1} = q - 1\right)
\end{array}
$$

$$
\begin{array}{l}
\stackrel {2. (1 1)} {=} \frac {1}{2 t _ {k - 1} + 2 i + q - 1} \cdot \frac {(q - 1) !}{2 ^ {0} (q - 1) ! 0 !} 2 ^ {q - 1} \frac {(2 t _ {k - 1} + 2 i + q - 2) !}{(2 t _ {k - 1} + 2 i + 2 q - 3) !} \frac {(t _ {k - 1} + i + q - 2) !}{(t _ {k - 1} + i - 1) !} \\
= \left(2 t _ {k - 1} + 2 i + q - 1\right) \cdot \frac {(q - 1) !}{2 ^ {0} (q - 1) ! 0 !} 2 ^ {q} \frac {(2 t _ {k - 1} + 2 i + q - 2) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 1) !}{(t _ {k - 1} + i - 1) !} \\
= \frac {(q - 1) !}{2 ^ {0} (q - 1) ! 0 !} 2 ^ {q} \frac {(2 t _ {k - 1} + 2 i + q - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 1) !}{(t _ {k - 1} + i - 1) !} \\
= \frac {(q) !}{2 ^ {0} (q) ! 0 !} 2 ^ {q} \frac {(2 t _ {k - 1} + 2 i + q - 1) !}{(2 t _ {k - 1} + 2 i + 2 q - 1) !} \frac {(t _ {k - 1} + i + q - 1) !}{(t _ {k - 1} + i - 1) !} \\
= P \left(\tilde {Y} _ {i, q} = q\right) \tag {14}
\end{array}
$$