Florian Stober and Armin Weiβ

Because of the insertion order, every element $b_{i}$ which is part of the $k$-th batch is inserted into at most $2^{k}-1$ elements; thus, it can be inserted by binary insertion using at most $k$ comparisons.

![img-2.jpeg](img-2.jpeg)

Regarding the average number of comparisons $F(n)$ we make the following observations: the first step always requires $\left\lfloor \frac{n}{2} \right\rfloor$ comparisons. The recursion step does not do any comparisons by itself but depends on the other steps. The average number of comparisons $G(n)$ required in the insertion step is not obvious. It will be studied closer in following chapters. Following [7], we obtain the recurrence (which is the same as for the worst-case number of comparisons)

$$
F(n) = \left\lfloor \frac{n}{2} \right\rfloor + F \left(\left\lfloor \frac{n}{2} \right\rfloor\right) + G \left(\left\lceil \frac{n}{2} \right\rceil\right). \tag{1}
$$

# 3 Average Case Analysis of the Insertion Step

In this section we have a look at different probabilities when inserting one batch of elements, i.e., the elements $b_{t_k}$ to $b_{t_{k-1}+1}$. We assume that all elements of previous batches, i.e., $b_1$ to $b_{t_{k-1}}$, have already been inserted and together with the corresponding $a_i$ they constitute the main chain and have been renamed to $x_1$ to $x_{2t_{k-1}}$ such that $x_i &lt; x_{i+1}$. The situation is shown in Fig. 1.

We will look at the element $b_{t_k + i}$ and want to answer the following questions: what is the probability of it being inserted between $x_j$ and $x_{j+1}$? And what is the probability of it being inserted into a specific number of elements?

![img-3.jpeg](img-3.jpeg)
Fig. 1: Configuration where a single batch of elements remains to be inserted

We can ignore batches that are inserted after the batch we are looking at since those do not affect the probabilities we want to obtain.

First we define a probability space for the process of inserting one batch of elements: let $\Omega_{k}$ be the set of all possible outcomes (i.e., linear extensions) when sorting the partially ordered elements shown in Fig. 1 by inserting $b_{t_k}$ to $b_{t_{k-1}+1}$. Each $\omega \in \Omega_{k}$ can be viewed as a function that maps an element $e$ to its final position, i.e., $\omega(e) \in \{1,2,\ldots,2t_k\}$. While the algorithm mandates a specific order for inserting the elements $b_{t_{k-1}+1}$ to $b_{t_k}$ during the insertion step, using a different order does not change the outcome, i.e., the elements are still sorted correctly. For this reason we can assume a different insertion in order to simplify calculating the likelihood of relations between individual elements.