On the Average Case of MergeInsertion

Algorithm 3 Computation of  $G(n)$
1: procedure COMPUTEG(n)
2:  $k \gets 2$
3:  $c \gets 0$
4: while  $t_k &lt; n$  do
5:  $c \gets c + \mathrm{COST}(t_{k-1}, t_k)$
6:  $k \gets k + 1$
7: end while
8:  $c \gets c + \mathrm{COST}(t_{k-1}, n)$
9: return  $c$
10: end procedure

Algorithm 4 Computation of  $\mathrm{Cost}(s,e)$
1: procedure COST(s, e)
2:  $r \gets e - s$  ▷ next element to be inserted is  $b_r$
3:  $q_1 \gets 2s$  ▷ number of elements on the main chain that are  $&lt; a_{s+1}$
4:  $q_2, \ldots, q_r \gets 0$  ▷  $q_i$  is the number of elements between  $as + i - 1$  and  $a_{s+i}$
5:  $(p, l) \gets \mathrm{COSTINSERT}(r, q_1, \ldots, q_r)$
6: return  $\frac{p}{r}$
7: end procedure
8:
9: procedure COSTINSERT(r,  $q_1, \ldots, q_r$ )
10: if  $r = 0$  then
11: return (0, 1) ▷ We reached a leave
12: end if
13: elements  $\gets r - 1 + \sum q_i$  ▷ number of elements  $b_r$  is inserted into
14:  $k \gets [\log(\text{elements} + 1)]$
15: cheap_insertions  $\gets 2^k - \text{elements} - 1$
16:  $p \gets 0$  ▷ external path length
17:  $l \gets 0$  ▷ number of leaves
18: index  $\gets 0$  ▷ We iterate over all indices where  $b_r$  can be inserted
19: for all  $0 &lt; i \leq r$  do
20:  $(p_c, l_c) \gets \mathrm{COSTINSERT}(r - 1, q_1, \ldots, q_{i-1}, q_i + 1, q_{i+1}, \ldots, q_{r-1})$
21: repeat  $q_i + 1$  times ▷  $q_i + 1$  positions between  $a_{s+i-1}$  and  $a_{s+i}$
22: if index &lt; cheap_insertions then
23:  $p \gets p + p_c + (k - 1) \cdot l_c$
24: else
25:  $p \gets p + p_c + k \cdot l_c$
26: end if
27:  $l \gets l + l_c$
28: index  $\gets$  index + 1
29: end
30: end for
31: return (p, l)
32: end procedure