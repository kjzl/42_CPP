On the Average Case of MergeInsertion

Now we calculate

$$
\begin{array}{l}
S (n) = F _ {\text {w o r s t - c a s e}} (m) - F _ {\text {a v e r a g e - c a s e}} (m) \\
= \left\lfloor \frac {n}{2} \right\rfloor + F _ {\text {w o r s t - c a s e}} \left(\left\lfloor \frac {n}{2} \right\rfloor\right) + G _ {\text {w o r s t - c a s e}} \left(\left\lceil \frac {n}{2} \right\rceil\right) \\
- \left\lfloor \frac {n}{2} \right\rfloor - F _ {\text {a v e r a g e - c a s e}} \left(\left\lfloor \frac {n}{2} \right\rfloor\right) - G _ {\text {a v e r a g e - c a s e}} \left(\left\lceil \frac {n}{2} \right\rceil\right) \\
= S \left(\left\lfloor \frac {n}{2} \right\rfloor\right) + G _ {\text {w o r s t - c a s e}} \left(\left\lceil \frac {n}{2} \right\rceil\right) - G _ {\text {a v e r a g e - c a s e}} \left(\left\lceil \frac {n}{2} \right\rceil\right) \\
\geq S \left(\left\lfloor \frac {n}{2} \right\rfloor\right) + \left(m - 2 ^ {l _ {m} - \log 3}\right) \left(\frac {2 ^ {l _ {m}}}{m + 2 ^ {l _ {m} - \log 3}} - 1\right) + \frac {1}{7 6 4} \frac {2 ^ {l _ {m}}}{3} \pm \mathcal {O} (\log m) \tag {20}
\end{array}
$$

We split  $S(n)$  into  $S_{\alpha}(n) + S_{\beta}(n)$  with

$$
S _ {\alpha} (n) \geq S _ {\alpha} \left(\left\lfloor \frac {n}{2} \right\rfloor\right) + \left(m - 2 ^ {l _ {m} - \log 3}\right) \left(\frac {2 ^ {l _ {m}}}{m + 2 ^ {l _ {m} - \log 3}} - 1\right)
$$

$$
S _ {\beta} (n) \geq S _ {\beta} \left(\left\lfloor \frac {n}{2} \right\rfloor\right) + \frac {1}{7 6 4} \frac {2 ^ {l _ {m}}}{3} \pm \mathcal {O} (\log m)
$$

From [4] we know  $S_{\alpha}(n) \geq \left(n - 2^{l_n - \log 3}\right)\left(\frac{2^{l_n}}{n + 2^{l_n - \log 3}} - 1\right) + \mathcal{O}(1)$ .

For  $S_{\beta}(n)$  we obtain

$$
\begin{array}{l}
S _ {\beta} (n) \geq \sum_ {i = 1} ^ {l _ {n} - 1} \frac {2 ^ {i}}{7 6 4 \cdot 3} \pm \mathcal {O} (\log 2 ^ {i}) \\
= \frac {2 ^ {l _ {n}}}{2 2 9 2} \pm \mathcal {O} \left(\log^ {2} n\right)
\end{array}
$$

We can represent  $n$  as  $2^{k - \log 3 + x_n}$  with  $x_{n}\in [0,1)$ . This leads to

$$
\begin{array}{l}
\frac {S (n)}{n} = \frac {S _ {\alpha} (n) + S _ {\beta} (n)}{n} \\
= \frac {2 ^ {k - \log 3 + x _ {n}} - 2 ^ {k - \log 3}}{2 ^ {k - \log 3 + x _ {n}}} \left(\frac {2 ^ {k}}{2 ^ {k - \log 3 + x _ {n}} + 2 ^ {k - \log 3}} - 1\right) + \frac {2 ^ {k}}{2 2 9 2 \cdot 2 ^ {k - \log 3 + x _ {n}}} \pm \mathcal {O} \left(\frac {\log^ {2} n}{n}\right) \\
= \left(1 - 2 ^ {- x _ {n}}\right) \left(\frac {3}{2 ^ {x _ {n}} + 1} - 1\right) + \frac {2 ^ {\log 3 - x _ {n}}}{2 2 9 2} \pm \mathcal {O} \left(\frac {\log^ {2} n}{n}\right)
\end{array}
$$

By writing  $F(n)$  as  $F(n) = n\log n - c(x_{n})\cdot n\pm \mathcal{O}(\log^{2}n)$  we get

$$
\begin{array}{l}
c \left(x _ {n}\right) \geq - \frac {\left(F (n) - n \log n\right)}{n} \\
= - \frac {\left(W (n) - S (n) - n \log n\right)}{n} \\
= (3 - \log 3) - (y + 1 - 2 ^ {y}) + (1 - 2 ^ {- x _ {n}}) \left(\frac {3}{2 ^ {x _ {n}} + 1} - 1\right) + \frac {2 ^ {\log 3 - x _ {n}}}{2 2 9 2}
\end{array}
$$

With  $y = 1 - x_{n}$  we obtain Theorem 3.