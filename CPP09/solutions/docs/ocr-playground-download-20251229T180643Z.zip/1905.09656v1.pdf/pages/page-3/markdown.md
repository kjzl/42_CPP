On the Average Case of MergeInsertion

- We compare MergeInsertion to the recent combination by Iwama and Teruyama [6] showing that, in fact, their combined algorithm is still better than the analysis and with the different insertion order can be further improved.

Most proofs as well as additional explanations and experimental results can be found in the appendix. The code used in this work and the generated data is available on [12].

# 2 Preliminaries

Throughout, we assume that the input consists of  $n$  distinct elements. The average case complexity is the mean number of comparisons over all input permutations of  $n$  elements.

Description of MergeInsertion The MergeInsertion algorithm consists of three phases: pairwise comparison, recursion, and insertion. Accompanying the explanations we give an example where  $n = 21$ . We call such a set of relations between individual elements a configuration.

1. Pairwise comparison. The elements are grouped into  $\left\lfloor \frac{n}{2} \right\rfloor$  pairs. Each pair is sorted using one comparison. After that, the elements are called  $a_1$  to  $a_{\left\lfloor \frac{n}{2} \right\rfloor}$  and  $b_1$  to  $b_{\left\lceil \frac{n}{2} \right\rceil}$  with  $a_i &gt; b_i$  for all  $1 \leq i \leq \left\lfloor \frac{n}{2} \right\rfloor$ .

![img-0.jpeg](img-0.jpeg)

2. Recursion. The  $\left\lfloor \frac{n}{2} \right\rfloor$  larger elements, i.e.,  $a_1$  to  $a_{\left\lfloor \frac{n}{2} \right\rfloor}$  are sorted recursively. Then all elements (the  $\left\lfloor \frac{n}{2} \right\rfloor$  larger ones as well as the corresponding smaller ones) are renamed accordingly such that  $a_i &lt; a_{i+1}$  and  $a_i &gt; b_i$  still holds.

![img-1.jpeg](img-1.jpeg)

3. Insertion. The  $\left\lceil \frac{n}{2} \right\rceil$  small elements, i.e., the  $b_{i}$ , are inserted into the main chain using binary insertion. The term "main chain" describes the set of elements containing  $a_{1}, \ldots, a_{t_{k}}$  as well as the  $b_{i}$  that have already been inserted.

The elements are inserted in batches starting with  $b_{3}, b_{2}$ . In the  $k$ -th batch the elements  $b_{t_k}, b_{t_{k-1}}, \ldots, b_{t_{k-1}+1}$  where  $t_k = \frac{2^{k+1} + (-1)^k}{3}$  are inserted in that order. Elements  $b_j$  where  $j &gt; \left\lceil \frac{n}{2} \right\rceil$  (which do not exist) are skipped. Note that technically  $b_1$  is the first batch; but inserting  $b_1$  does not need any comparison.