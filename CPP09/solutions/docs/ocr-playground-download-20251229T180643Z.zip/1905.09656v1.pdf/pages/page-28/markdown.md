Florian Stober and Armin Wei

![img-27.jpeg](img-27.jpeg)
Fig. 19: Configuration where one batch of  $e - s$  elements,  $b_{s + 1}$  to  $b_{e}$ , remains to be inserted.

# C Details on Computing the Exact Number of Comparisons

The code for calculating  $F(n)$  and  $G(n)$  is shown in Algorithm 2 and Algorithm 3 respectively.

$\mathrm{Cost}(s,e)$  is the number of comparisons required for inserting the batch of elements that consists of  $b_{s+1}$  to  $b_e$ . Such a configuration can be seen in Fig. 19.  $\mathrm{Cost}(s,e)$  is computed by calculating the external path length of the decision tree and dividing by the number of leaves. To improve performance we apply the following optimization: We collapse "identical" branches of the decision tree. E.g. whether  $b_e$  is inserted between  $x_1$  and  $x_2$  or between  $x_2$  and  $x_3$  does not influence the number of comparisons required to insert the subsequent elements. So we can neglect that difference. However, if  $b_e$  is inserted between  $a_{e-1}$  and  $a_e$  then the next element (and all thereafter) is inserted into one less element. So this is a difference we need to acknowledge. Same if an element is inserted between any  $a_i$  and  $a_{i+1}$ . By the time we insert  $b_i$  the element inserted between  $a_i$  and  $a_{i+1}$  is known to be larger than  $b_i$  and thus is no longer part of the main chain, resulting in  $b_i$  being inserted into one element less. In conclusion that means that our algorithm needs to keep track of the elements inserted between any  $a_i$  and  $a_{i+1}$  as well as those inserted at any position before  $a_{s+1}$  as two branches of the decision tree that differ in any of these cannot be collapsed. Algorithm 4 shows how this is implemented.

Algorithm 2 Computation of  $F(n)$
1: procedure COMPUTEF(n)
2: if  $n = 1$  then
3: return 0
4: else
5: return  $\lfloor \frac{n}{2} \rfloor + \text{COMPUTEF}(\lfloor \frac{n}{2} \rfloor) + \text{COMPUTEG}(\lceil \frac{n}{2} \rceil)$
6: end if
7: end procedure