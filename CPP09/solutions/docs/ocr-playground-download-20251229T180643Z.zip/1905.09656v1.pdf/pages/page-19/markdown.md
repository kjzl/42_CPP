On the Average Case of MergeInsertion

To proof Theorem 2 we start with the following closed form for the probability $P(\tilde{Y}_{i,q} = j)$.

$$
P \left(\tilde {Y} _ {i, q} = j\right) = \frac {(2 q - j) !}{2 ^ {q - j} j ! (q - j) !} 2 ^ {q} \frac {\left(2 t _ {k - 1} + 2 i + j - 1\right) !}{\left(2 t _ {k - 1} + 2 i + 2 q - 1\right) !} \frac {\left(t _ {k - 1} + i + q - 1\right) !}{\left(t _ {k - 1} + i - 1\right) !} \tag {8}
$$

From the definition of $\tilde{Y}_{i,q}$ we can see that $0\leq \tilde{Y}_{i,q}\leq q$ thus $P(\tilde{Y}_{i,0} = 0) = 1$. This also holds for Eq. (8).

$$
P \left(\tilde {Y} _ {i, 0} = 0\right) = \frac {0 !}{2 ^ {0} \cdot 0 ! \cdot 0 !} 2 ^ {0} \frac {\left(2 t _ {k - 1} + 2 i - 1\right) !}{\left(2 t _ {k - 1} + 2 i - 1\right) !} \frac {\left(t _ {k - 1} + i - 1\right) !}{\left(t _ {k - 1} + i - 1\right) !} = 1 \tag {9}
$$

Recall that for $q &gt; 0$ there are two possibilities:

1. $\tilde{Y}_{i,q-1} = j - 1$ and $X_{i+q} &lt; 2t_{k-1} + i$. Informally speaking that means out of $\{b_{t_{k-1} + i+1}, \ldots, b_{t_{k-1} + i+q-1}\}$ there have been $j - 1$ elements inserted before $a_{t_{k-1} + i}$ and $b_{t_{k-1} + i+q}$ is inserted before $a_{t_{k-1} + i}$.
2. $\tilde{Y}_{i,q-1} = j$ and $X_{i+q} \geq 2t_{k-1} + i$. Informally speaking that means out of $\{b_{t_{k-1} + i+1}, \ldots, b_{t_{k-1} + i+q-1}\}$ there have been $j$ elements inserted before $a_{t_{k-1} + i}$ and $b_{t_{k-1} + i+q}$ is inserted after $a_{t_{k-1} + i}$.

Note that the first case requires $j &gt; 0$ and the second case requires $j &lt; q$ so we look at $j = 0$ and $j = q$ separately.

Using Bayes' theorem we obtain the following identities:

$$
\begin{array}{l}
P \left(X _ {i + q} \geq 2 t _ {k - 1} + i \wedge \tilde {Y} _ {i, q - 1} = 0\right) = P \left(X _ {i + q} \geq 2 t _ {k - 1} + i \mid \tilde {Y} _ {i, q - 1} = 0\right) \cdot P \left(\tilde {Y} _ {i, q - 1} = 0\right) \\
P \left(X _ {i + q} &lt; 2 t _ {k - 1} + i \wedge \tilde {Y} _ {i, q - 1} = q - 1\right) = P \left(X _ {i + q} &lt; 2 t _ {k - 1} + i \mid \tilde {Y} _ {i, q - 1} = q - 1\right) \cdot P \left(\tilde {Y} _ {i, q - 1} = q - 1\right) \tag {10}
\end{array}
$$

The probability $P(X_{i + q} &lt; 2t_{k - 1} + i \mid Y_{i,q - 1} = d)$ can be obtained by looking at Fig. 16 and counting elements. When $b_{t_{k - 1} + i + q}$ is inserted, the elements on the main chain which are smaller than $a_{t_{k - 1} + i}$ are $x_{1}$ to $x_{2t_{k - 1}}$, $a_{t_{k - 1} + 1}$ to $a_{t_{k - 1} + i - 1}$ and $d$ elements out of $\{b_{t_{k - 1} + i + 1}, \ldots, b_{t_{k - 1} + i + q - 1}\}$ which is a total of $2t_{k - 1} + 2i - 1 + d$ elements. Combined with the fact that the main chain consists of $2t_{k - 1} + 2i + 2q - 2$ elements smaller than $a_{t_{k - 1} + i + q}$ we obtain the following formula

$$
P \left(X _ {i + q} &lt; 2 t _ {k - 1} + i \mid Y _ {i, q - 1} = d\right) = \frac {2 t _ {k - 1} + 2 i + d}{2 t _ {k - 1} + 2 i + 2 q - 1} \tag {11}
$$

1 The first part of Eq. (8): $\frac{(2q-j)!}{2^{q-j}j!(q-j)!}$, when substituting $q = n$ and $j = n-k$ yields $a(n,k) = \frac{(n+k)!}{2^k(n-k)!k!}$ which is the number sequence A001498 from The On-Line Encyclopedia of Integer Sequences https://oeis.org/A001498.