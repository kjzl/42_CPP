Florian Stober and Armin Weiß

$$
\begin{array}{l}
= \alpha_{m} (m - t_{k_{m}-1}) + \frac{1}{764} (t_{k_{m-1}} - t_{1}) \pm \mathcal{O}(\log m) \\
= \alpha_{m} (m - t_{k_{m}-1}) + \frac{1}{764} t_{k_{m-1}} \pm \mathcal{O}(\log m) \\
= \alpha_{m} (m - t_{k_{m}-1}) + \frac{1}{764} \frac{2_{m}^{k} + (-1)^{k_{m}-1}}{3} \pm \mathcal{O}(\log m) \\
= \alpha_{m} (m - t_{k_{m}-1}) + \frac{1}{764} \frac{2^{k_{m}}}{3} \pm \mathcal{O}(\log m) \tag{19}
\end{array}
$$

By writing $m$ as $m = 2^{l_m - \log 3 + x}$ with $x \in [0,1)$ we get $l_m = \lfloor \log 3m \rfloor$. To approximate $k_m$ with $l_m$ we need to show that $k_m \geq l_m$. Recall that $t_{k_m - 1} \leq m &lt; t_{k_m}$. For all $t_{k_m - 1} &lt; m &lt; t_{k_m}$ we have

$$
\frac{2^{k_{m}} + (-1)^{k_{m}-1}}{3} &lt; m &lt; \frac{2^{k_{m}+1} + (-1)^{k_{m}}}{3}
$$

Since $m \in \mathbb{N}$ and $t_k \in \mathbb{N}$ adding/subtracting $\frac{1}{3}$ does not alter the relation, so we obtain

$$
\frac{2^{k_{m}}}{3} &lt; m &lt; \frac{2^{k_{m}+1}}{3}
$$

which resolves to

$$
k_{m} &lt; \log 3n &lt; k_{m} + 1
$$

Thus $k_{m} = \lfloor \log 3m \rfloor = l_{m}$.

For $m = t_{k_m - 1}$ we get

$$
\begin{array}{l}
\frac{2^{k_{m}} + (-1)^{k_{m}-1}}{3} = m \\
\Longleftrightarrow \quad 2^{k_{m}} = 3m + (-1)^{k_{m}} \\
\Longleftrightarrow \quad k_{m} = \log \left(3m + (-1)^{k_{m}}\right) \\
\end{array}
$$

If $k_m = \log (3m + 1)$ that resolves to $k_m = \log (3m + 1) &gt; \log (3m) &gt; \lfloor \log 3m \rfloor = l_m$.

If instead $k_m = \log (3m - 1)$ using $k_m \in \mathbb{N}$ we have $k_m = \lfloor \log (3m - 1) \rfloor$ and for all $m \geq 1$ this is equal to $\lfloor \log 3m \rfloor = l_m$.

Hence in all cases $l_m \leq k_m$ holds. Therefore we can replace $k_m$ with $l_m$ in Eq. (19):

$$
G_{\text{worst-case}}(m) - G_{\text{average-case}}(m) \geq \alpha_{m} (m - t_{k_{m}-1}) + \frac{1}{764} \frac{2^{l_{m}}}{3} \pm \mathcal{O}(\log m)
$$

From [4] we know that the $\alpha_{m}(m - t_{k_{m}-1})$ term can be approximated with $(m - 2^{l_{m} - \log 3})\left(\frac{2^{l_{m}}}{m + 2^{l_{m} - \log 3}} - 1\right)$.

$$
\begin{array}{l}
G_{\text{worst-case}}(m) - G_{\text{average-case}}(m) \\
\geq \left(m - 2^{l_{m} - \log 3}\right) \left(\frac{2^{l_{m}}}{m + 2^{l_{m} - \log 3}} - 1\right) + \frac{1}{764} \frac{2^{l_{m}}}{3} \pm \mathcal{O}(\log m) \\
\end{array}
$$