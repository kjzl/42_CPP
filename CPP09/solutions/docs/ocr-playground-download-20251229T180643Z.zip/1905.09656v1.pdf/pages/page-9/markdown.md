On the Average Case of MergeInsertion

For  $n \in \{1, \ldots, 15\}$  the computed values are shown in Table 1, for larger  $n$ . Fig. 7 shows the values we computed. The complete data set is provided in the file exact.csv in [12]. Our results match up with the values for  $n \in \{1, \ldots, 8\}$  calculated in [7]. Note that for these values the chosen insertion strategy does not affect the average case (we use the left strategy).

![img-12.jpeg](img-12.jpeg)
Fig. 7: Computed values of  $F(n)$ .

![img-13.jpeg](img-13.jpeg)
Table 1: Computed values of  $F\left( n\right)  \cdot  n$  !.

Improved theoretical upper bounds In this section we improve upon the upper bound from [3] leading to the following result:

Theorem 3. The number of comparisons required in the average case of Merge-Insertion is at most  $n \log n - c(x_n) \cdot n \pm \mathcal{O}(\log^2 n)$  where  $x_n$  is the fractional part of  $\log(3n)$ , i.e., the unique value in  $[0,1)$  such that  $n = 2^{k - \log 3 + x_n}$  for some  $k \in \mathbb{Z}$  and  $c: [0,1) \to \mathbb{R}$  is given by the following formula:

$$
c (x) = (3 - \log 3) - (2 - x - 2 ^ {1 - x}) + (1 - 2 ^ {- x}) \left(\frac {3}{2 ^ {x} + 1} - 1\right) + \frac {2 ^ {\log 3 - x}}{2 2 9 2} \geq 1. 4 0 0 5
$$

Hence we have obtained a new upper bound for the average case of MergeInsertion which is  $n \log n - 1.4005n + \mathcal{O}(\log^2 n)$ . A visual representation of  $c(x)$  is provided in Fig. 8. The worst case is near  $x = 0.6$  (i.e.,  $n$  roughly a power of two) where  $c(x)$  is just slightly larger than 1.4005.

The proof of Theorem 3 analyzes the insertion of one batch of elements more carefully than in [4]. The exact probability that  $b_{t_{k-1}+i}$  is inserted into  $j$  elements is given by Theorem 2. We are especially interested in the case of  $b_{t_{k-1}+u}$  where  $u = \left\lfloor \frac{t_k - t_{k-1}}{2} \right\rfloor$ , because, if we know  $P(Y_u &lt; m)$ , then we can use that for all  $q &lt; u$  we have  $P(Y_q &lt; m) \geq P(Y_u &lt; m)$ .

However, the equation from Theorem 2 is hard to work with, so we approximate it with the binomial distribution  $p(j) = \left(\left\lceil \frac{q}{q} \right\rceil\right)\left(\frac{\lfloor \frac{q}{2} \rfloor}{2t_k - 1}\right)^q\left(\frac{2t_k - 1 - \lfloor \frac{q}{2} \rfloor}{2t_k - 1}\right)\left\lceil \frac{q}{2} \right\rceil - q$  with  $q = 2^k - 1 - j$ , that by construction fulfills  $\sum_{j=0}^{j_0} p(j) \leq \sum_{j=0}^{j_0} P(Y_u = j) = P(Y_u \leq j_0)$  for all  $j_0$ . By using the approximation  $P(Y_u = j) \approx p(j)$  we can calculate a lower bound for the median of  $Y_{\frac{t_k - t_{k-1}}{2}}$  which is  $2^k - 1 - \lfloor n_B \cdot p_B \rfloor \in 2^k - 1 - \frac{2^{k-6}}{3} + \mathcal{O}(1)$ . Thus, with a probability of one half the elements  $b_{t_{k-1}+i}$