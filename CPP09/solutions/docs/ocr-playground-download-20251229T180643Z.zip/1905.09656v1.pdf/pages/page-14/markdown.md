Florian Stober and Armin Weiß

# A Tables and Figures

![img-19.jpeg](img-19.jpeg)

![img-20.jpeg](img-20.jpeg)

![img-21.jpeg](img-21.jpeg)
(a) Batch  $k = 2$
(b) Batch  $k = 3$
(c) Batch  $k = 4$

![img-22.jpeg](img-22.jpeg)
Fig. 13: Batches of the elements  $b_{t_k}$  to  $b_{t_{k-1}+1}$  for  $k \in \{2,3,4\}$
Fig. 14: Probabilities of different positions when inserting  $b_{t_k}$  where  $k = 6$ .