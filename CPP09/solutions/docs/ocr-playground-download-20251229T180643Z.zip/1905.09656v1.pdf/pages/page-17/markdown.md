On the Average Case of MergeInsertion

# B Missing Proofs

# B.1 Proof of Theorem 1

For an arbitrary  $k$  we can calculate the probabilities  $P(X_{i} = j)$  with the following recursive scheme. We start with  $P(X_{1} = j)$ . This corresponds to the insertion of  $b_{t_{k - 1} + 1}$  into  $x_{1},\ldots ,x_{2t_{k - 1}}$ . The probability of all those is uniformly distributed, so  $P(X_{1} = j) = \frac{1}{2t_{k - 1} + 1}$  for  $0\leq j\leq 2t_{k - 1}$ .

For  $i &gt; 1$  we can express  $P(X_{i} = j)$  in terms of  $P(X_{i - 1} = j)$ . Observe that when inserting  $b_{t_{k - 1} + i}$  there are  $2t_{k - 1} + 2i - 2$  elements known to be smaller than  $a_{t_{k - 1} + i}$ . These are  $x_{1},\ldots ,x_{2t_{k - 1}}$  and  $a_{t_{k - 1} + 1},\ldots ,a_{t_{k - 1} + i - 1}$  as well as the corresponding  $b$ 's. The number of elements known to be smaller than  $a_{t_{k - 1} + i - 1}$  is one less: just  $2t_{k - 1} + 2i - 3$ . As a result the probability that  $b_{t_{k - 1} + i}$  is inserted between  $a_{t_{k - 1} + i - 1}$  and  $a_{t_{k - 1} + i}$  is  $P(X_{i} = 2t_{k - 1} + i - 1) = \frac{1}{2t_{k - 1} + 2i - 1}$ . The probability that is ends up in one of the other positions consequently is  $P(0\leq X_i &lt; 2t_{k - 1} + i - 1) = \frac{2t_{k - 1} + 2i - 2}{2t_{k - 1} + 2i - 1}$ . If we know that  $b_{t_{k - 1} + i}$  is inserted into one of those other positions, then it is inserted into exactly the same elements as  $b_{t_{k - 1} + i - 1}$ , thus we can write  $P(X_{i} = j) = \frac{2t_{k - 1} + 2i - 2}{2t_{k - 1} + 2i - 1} P(X_{i - 1} = j)$ . This leads to Eq. (2).

$$
P \left(X _ {i} = j\right) = \left\{ \begin{array}{l l} \left(\prod_ {l = 1} ^ {i - 1} 2 t _ {k - 1} + 2 l\right) \cdot \left(\prod_ {l = 1} ^ {i} 2 t _ {k - 1} + 2 l - 1\right) ^ {- 1} &amp; \text {i f} 0 \leq j \leq 2 t _ {k - 1} \\ \left(\prod_ {l = j - 2 t _ {k - 1} + 1} ^ {i - 1} 2 t _ {k - 1} + 2 l\right) \cdot \left(\prod_ {l = j - 2 t _ {k - 1} + 1} ^ {i} 2 t _ {k - 1} + 2 l - 1\right) ^ {- 1} &amp; \text {i f} 2 t _ {k - 1} &lt;   j &lt;   2 t _ {k - 1} + i \\ 0 &amp; \text {o t h e r w i s e .} \end{array} \right. \tag {2}
$$

It remains to simplify Eq. (2). We begin with the first case:

$$
\begin{array}{l} \left(\prod_ {l = 1} ^ {i - 1} 2 t _ {k - 1} + 2 l\right) \cdot \left(\prod_ {l = 1} ^ {i} 2 t _ {k - 1} + 2 l - 1\right) ^ {- 1} \\ = \left(\prod_ {l = t _ {k - 1} + 1} ^ {t _ {k - 1} + i - 1} 2 l\right) \cdot \left(\prod_ {l = 2 t _ {k - 1} + 1} ^ {2 t _ {k - 1} + 2 i - 1} l\right) ^ {- 1} \cdot \left(\prod_ {l = t _ {k - 1} + 1} ^ {t _ {k - 1} + i - 1} 2 l\right) \\ = \left(\prod_ {l = 1} ^ {t _ {k - 1} + i - 1} 2 l\right) \cdot \left(\prod_ {l = 1} ^ {t _ {k - 1}} 2 l\right) ^ {- 1} \cdot \left(\prod_ {l = 1} ^ {2 t _ {k - 1} + 2 i - 1} l\right) ^ {- 1} \tag {3} \\ \cdot \left(\prod_ {l = 1} ^ {2 t _ {k - 1}} l\right) \cdot \left(\prod_ {l = 1} ^ {t _ {k - 1} + i - 1} 2 l\right) \cdot \left(\prod_ {l = 1} ^ {t _ {k - 1}} 2 l\right) ^ {- 1} \\ = 2 ^ {2 i - 2} \left(\frac {(t _ {k - 1} + i - 1) !}{(t _ {k - 1}) !}\right) ^ {2} \frac {(2 t _ {k - 1}) !}{(2 t _ {k - 1} + 2 i - 1) !} \\ \end{array}
$$