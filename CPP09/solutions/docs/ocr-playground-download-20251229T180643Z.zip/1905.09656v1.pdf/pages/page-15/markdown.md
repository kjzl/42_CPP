On the Average Case of MergeInsertion

|  i | 1 | 2 | 3 | 4 | 5 | 6  |
| --- | --- | --- | --- | --- | --- | --- |
|  P(Xi=0) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=1) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=2) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=3) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=4) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=5) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=6) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=7) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=8) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=9) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=10) | 1/11 | 1/11 | 12/13 | 1/11 | 12/13 | 14/15  |
|  P(Xi=11) | 0 | 1/15 | 1/13 | 1/13 | 1/13 | 1/13  |
|  P(Xi=12) | 0 | 0 | 1/15 | 1/15 | 1/15 | 1/15  |
|  P(Xi=13) | 0 | 0 | 0 | 1/17 | 1/17 | 1/17  |
|  P(Xi=14) | 0 | 0 | 0 | 0 | 1/15 | 1/15  |
|  P(Xi=15) | 0 | 0 | 0 | 0 | 0 | 1/21  |

Table 2: Values of  $P\left( {{X}_{i} = j}\right)$  for  $k = 4$  .

Algorithm 1 Binary Insertion
1: procedure INSERT(a,x1,...,xn)
2: if n = 0 then
3: return a
4: end if
5: k ← [log n]
6: c ← { [n+1/2] strategy center-left
[ n+1/2] strategy center-right
max{n-2^k+1,2^{k-1}} strategy left
min{2^k,n-2^{k-1}+1} strategy right
7: if a &lt; x_c then
8: y1,...,yc ← INSERT(a,x1,...,xc-1)
9: return y1,...,yc,xc,...,xn
10: else
11: yc,...,yn ← INSERT(a,xc+1,...,xn)
12: return x1,...,xc,yc,...,yn
13: end if
14: end procedure