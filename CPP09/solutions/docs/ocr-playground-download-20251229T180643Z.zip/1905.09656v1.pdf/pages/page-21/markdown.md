On the Average Case of MergeInsertion

3. Proof of Eq. (8) where $0 &lt; j &lt; q$ using

$$
\tilde{Y}_{i,q} = j \Leftrightarrow (X_{i+q} &lt; 2t_{k-1} + i \wedge \tilde{Y}_{i,q-1} = j - 1) \vee (X_{i+q} \geq 2t_{k-1} + i \wedge \tilde{Y}_{i,q-1} = j)
$$

$$
\begin{aligned}
P(X_{i+q} &amp;&lt; 2t_{k-1} + i \wedge \tilde{Y}_{i,q-1} = j - 1) \\
&amp;\quad + P(X_{i+q} \geq 2t_{k-1} + i \wedge \tilde{Y}_{i,q-1} = j) \\
&amp;= P\left(X_{i+q} &lt; 2t_{k-1} + i \mid \tilde{Y}_{i,q-1} = j - 1\right) \cdot P(\tilde{Y}_{i,q-1} = j - 1) \\
&amp;\quad + P\left(X_{i+q} \geq 2t_{k-1} + i \mid \tilde{Y}_{i,q-1} = j\right) \cdot P(\tilde{Y}_{i,q-1} = j)
\end{aligned}
$$

$$
\begin{aligned}
\text{Thm. 2. (11)} &amp; \left(\frac{122t_{k-1} + 2i + j - 1}{2t_{k-1} + 2i + 2q - 1} \cdot \frac{(2q - j - 1)!}{(2q - j)!} 2^{q - 1} \frac{(2t_{k-1} + 2i + j - 2)!}{(2t_{k-1} + 2i + 2q - 3)!} \frac{(t_{k-1} + i + q - 2)!}{(t_{k-1} + i - 1)!}\right) \\
&amp;\quad + \frac{2q - j - 1}{2t_{k-1} + 2i + 2q - 1} \cdot \frac{(2q - j - 2)!}{2^{q - j}(j - 1)!(q - j)!} 2^{q - 1} \frac{(2t_{k-1} + 2i + j - 1)!}{(2t_{k-1} + 2i + 2q - 3)!} \frac{(t_{k-1} + i + q - 2)!}{(t_{k-1} + i - 1)!} \\
&amp;= (2t_{k-1} + 2i + j - 1) \cdot \frac{(2q - j - 1)!}{2^{q - j}(j - 1)!(q - j)!} 2^{q} \frac{(2t_{k-1} + 2i + j - 2)!}{(2t_{k-1} + 2i + 2q - 1)!} \frac{(t_{k-1} + i + q - 1)!}{(t_{k-1} + i - 1)!} \\
&amp;\quad + (2q - j - 1) \cdot \frac{(2q - j - 2)!}{2^{q - j}(j - 1)!(q - j)!} 2^{q} \frac{(2t_{k-1} + 2i + j - 1)!}{(2t_{k-1} + 2i + 2q - 1)!} \frac{(t_{k-1} + i + q - 1)!}{(t_{k-1} + i - 1)!} \\
&amp;= \left(\frac{(2q - j - 1)!}{2^{q - j}(j - 1)!(q - j)!} + \frac{(2q - j - 1)!}{2^{q - j}(j - 1)!(q - j)!}\right) 2^{q} \frac{(2t_{k-1} + 2i + j - 1)!}{(2t_{k-1} + 2i + 2q - 1)!} \frac{(t_{k-1} + i + q - 1)!}{(t_{k-1} + i - 1)!} \\
&amp;= \left(\frac{j}{2q - j} + \frac{2(q - j)}{2q - j}\right) \frac{(2q - j)!}{2^{q - j}j!(q - j)!} 2^{q} \frac{(2t_{k-1} + 2i + j - 1)!}{(2t_{k-1} + 2i + 2q - 1)!} \frac{(t_{k-1} + i + q - 1)!}{(t_{k-1} + i - 1)!} \\
&amp;= \frac{(2q - j)!}{2^{q - j}j!(q - j)!} 2^{q} \frac{(2t_{k-1} + 2i + j - 1)!}{(2t_{k-1} + 2i + 2q - 1)!} \frac{(t_{k-1} + i + q - 1)!}{(t_{k-1} + i - 1)!} \\
&amp;= P(\tilde{Y}_{i,q} = j)
\end{aligned}
\tag{15}
$$

From Eq. (8) we can derive Theorem 2 using the Eq. (7).

$$
\begin{aligned}
P(Y_i = j) \\
&amp;= P(\tilde{Y}_{i,t_k - t_{k-1} - i} + 2t_{k-1} + i - 1 = j) \\
&amp;= P(\tilde{Y}_{i,t_k - t_{k-1} - i} = j - 2t_{k-1} - i + 1) \\
&amp;= \frac{(2t_k - 2t_{k-1} - 2i - j + 2t_{k-1} + i - 1)!}{2^{t_k - t_{k-1} - i - j + 2t_{k-1} + i - 1}(j - 2t_{k-1} - i + 1)! (t_k - t_{k-1} - i - j + 2t_{k-1} + 1 - 1)!} \\
&amp;\quad \cdot 2^{t_k - t_{k-1} - i} \frac{(2t_{k-1} + 2i + j - 2t_{k-1} - i + 1 - 1)!}{(2t_{k-1} + 2i + 2t_k - 2t_{k-1} - 2i - 1)!} \frac{(t_{k-1} + i + t_k - t_{k-1} - i - 1)!}{(t_{k-1} + i - 1)!} \\
&amp;= \frac{(2t_k - i - j - 1)!}{2^{2^k - j - 1} (-2t_{k-1} - 1 + j + 1)! (2^k - j - 1)!} \cdot 2^{t_k - t_{k-1} - i} \frac{(i + j)!}{(2t_k - 1)!} \frac{(t_k - 1)!}{(t_{k-1} + i - 1)!} \\
&amp;= 2^{j - 2t_{k-1} - i + 1} \frac{(2t_k - i - j - 1)!}{(-2t_{k-1} - 1 + j + 1)! (2^k - j - 1)!} \frac{(i + j)!}{(2t_k - 1)!} \frac{(t_k - 1)!}{(t_{k-1} + i - 1)!}
\end{aligned}
\tag{16}
$$

## B.3 Proof of Theorem 3

The exact probability that $b_{t_{k-1}+i}$ is inserted into $j$ elements is given by Theorem 2. We are especially interested in the case of $b_{t_{k-1}+u}$ where $u = \left\lfloor \frac{t_k - t_{k-1}}{2} \right\rfloor$, because if we know $P(Y_u &lt; m)$ then we can use that for all $q &lt; u$ the probability of $b_{t_{k-1}+q}$ being inserted into less than $m$ elements is at least $P(Y_u &lt; m)$,